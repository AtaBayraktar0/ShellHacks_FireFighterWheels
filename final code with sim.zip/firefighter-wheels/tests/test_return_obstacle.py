from unittest.mock import Mock
from firebot.config import Config
from firebot.isaac.return_obstacle import ReturnObstacle
from firebot.isaac.math_utils import rectangle_gap


def event(seed=0, boxes=()):
    path=[(i*.01,0.) for i in range(201)]
    return ReturnObstacle(path,seed,Config(),boxes,None,lambda _:None)


def test_spawns_only_after_return_travel_and_once():
    scenario=event()
    spawn=Mock()
    scenario.update((2.,0.),0.,spawn)
    scenario.update((1.99,0.),1.,spawn)
    spawn.assert_not_called()
    scenario.update((1.65,0.),3.,spawn)
    spawn.assert_called_once()
    bounds=spawn.call_args.args[0]
    assert rectangle_gap(1.65,0.,.145,bounds) > .4
    assert bounds[2] < 1.65
    scenario.update((1.6,0.),4.,spawn)
    spawn.assert_called_once()


def test_same_seed_repeats_event():
    events=[]
    for _ in range(2):
        scenario=event(7)
        scenario.update((2.,0.),0.,Mock())
        scenario.update((1.65,0.),3.,Mock())
        events.append(scenario.event)
    assert events[0] == events[1]
    assert events[0]['status']=='spawned'


def test_occupied_path_is_skipped_not_forced():
    scenario=event(boxes=[(-.5,-1.,2.5,1.)])
    spawn=Mock()
    scenario.update((2.,0.),0.,spawn)
    scenario.update((1.65,0.),3.,spawn)
    scenario.finish()
    spawn.assert_not_called()
    assert scenario.event['status']=='skipped'
