from types import SimpleNamespace
from unittest.mock import Mock
import math
import numpy as np
import pytest
from firebot.config import Config
from firebot.rescue_mission import Mission, MissionFailed, RouteUnavailable
from firebot.grid import FREE, OCC, FIRE, UNKNOWN, Observation
from firebot.isaac import return_recovery as recovery


def mission():
    base=Mock()
    base.heading.return_value=None
    base.turn.side_effect=lambda angle:angle
    base.move.side_effect=lambda distance:(distance,False)
    camera=Mock()
    camera.observe.return_value=Observation()
    m=Mission(Config(),base,camera,log=lambda _:None)
    m.pose.x=1.
    m.grid.state[:]=FREE
    m.return_trip=Mock(side_effect=RouteUnavailable('no route'))
    m.driven_back=[(1.5,0.),m.pose.xy]
    return m


def run(m,**kwargs):
    recovery.return_with_exploration(m,SimpleNamespace(time=lambda:0.),lambda _:None,**kwargs)


def test_normal_return_needs_no_recovery():
    m=mission()
    m.return_trip.side_effect=None
    run(m)
    m.camera.observe.assert_not_called()


def test_scan_reveals_home_route_and_preserves_history_and_config():
    m=mission()
    before=m.cfg.assumed_depth_m
    run(m)
    assert math.dist(m.pose.xy,m.start)<m.cfg.goal_tolerance_m
    assert m.driven_back[:2]==[(1.5,0.),(1.,0.)]
    assert m.cfg.assumed_depth_m==before
    assert m.return_recovery_attempts==1


def test_unknown_floor_cannot_be_used():
    m=mission()
    m.grid.state[:]=UNKNOWN
    with pytest.raises(MissionFailed,match='exhausted reachable'):
        run(m)
    m.base.move.assert_not_called()


def test_surface_mask_retains_obstacle_fire_and_edge_clearance():
    m=mission()
    m.grid.mark((.5,.4),OCC)
    m.grid.mark((1.5,.4),FIRE)
    mask=recovery.recovery_mask(m)
    for point in ((.5,.25),(1.5,.15),(-.475,0)):
        x,y=m.grid.cell(point)
        assert mask[y,x]


def test_viewpoint_can_be_reached_around_corner():
    m=mission()
    m.pose.x=0.
    m.grid.state[:]=FREE
    for y in np.arange(-1.25,.35,.05):
        m.grid.mark((.55,y),OCC)
    mask=recovery.recovery_mask(m)
    # Treat nearby positions as visited so the destination is on the far side.
    visited=[m.grid.center((x,y)) for y,x in np.argwhere(~mask)
             if m.grid.center((x,y))[0]<.85]
    path=recovery.viewing_route(m,mask,visited)
    assert path is not None and path[-1][0]>.85
    assert not m.grid.segment_clear(mask,m.pose.xy,path[-1])
    assert all(m.grid.segment_clear(mask,a,b) for a,b in zip(path,path[1:]))


def test_fresh_obstacle_blocks_motion(monkeypatch):
    m=mission()
    m.look_ahead=lambda:m.grid.state.fill(OCC)
    with pytest.raises(MissionFailed):
        run(m,max_moves=1)
    m.base.move.assert_not_called()


def test_deadline_stops_before_motion():
    m=mission()
    ticks=iter([0.,0.,241.])
    with pytest.raises(MissionFailed,match='time budget'):
        recovery.return_with_exploration(m,SimpleNamespace(time=lambda:next(ticks)),lambda _:None)
    m.base.move.assert_not_called()


def test_physics_failure_is_not_treated_as_route_failure():
    m=mission()
    m.return_trip.side_effect=RuntimeError('collision guard')
    with pytest.raises(RuntimeError,match='collision guard'):
        run(m)
    m.camera.observe.assert_not_called()


def test_unknown_near_path_blocks_full_footprint():
    m=mission()
    m.grid.mark((.5,.15),UNKNOWN)
    mask=recovery.recovery_mask(m)
    x,y=m.grid.cell((.5,0.))
    assert mask[y,x]


def test_control_timeout_is_not_recovered():
    m=mission()
    m.return_trip.side_effect=MissionFailed('Isaac turn timed out')
    with pytest.raises(MissionFailed,match='turn timed out'):
        run(m)
    m.camera.observe.assert_not_called()


def test_viewpoint_then_new_home_route(monkeypatch):
    m=mission()
    original=recovery.route
    tries=[]
    def home_route(mission,mask,target):
        if target==mission.start:
            tries.append(target)
            if len(tries)==1:
                return None
        return original(mission,mask,target)
    monkeypatch.setattr(recovery,'route',home_route)
    monkeypatch.setattr(recovery,'viewing_route',
                        lambda mission,mask,visited:original(mission,mask,(.7,.5)))
    run(m)
    assert len(tries)==2
    assert m.return_recovery_moves==2
    assert math.dist(m.pose.xy,m.start)<m.cfg.goal_tolerance_m


def test_repeated_new_obstacle_is_bounded(monkeypatch):
    m=mission()
    # A fresh frame rejects the selected leg each time; scanning clears it.
    m.look_ahead=lambda:m.grid.state.fill(OCC)
    m.scan=lambda:m.grid.state.fill(FREE)
    with pytest.raises(MissionFailed,match='move budget'):
        run(m,max_moves=2)
    assert m.return_recovery_attempts==3
    assert m.return_recovery_moves==0
    m.base.move.assert_not_called()
