import numpy as np
import pytest
from types import SimpleNamespace
from unittest.mock import Mock
from firebot.config import Config
from firebot.isaac.person import detect_person, acquire_person
from firebot.rescue_mission import Mission, MissionFailed
from firebot.grid import Observation, FREE, OCC


def search_mission():
    base = Mock()
    base.heading.return_value = None
    base.turn.side_effect = lambda angle: angle
    camera = Mock()
    camera.observe.return_value = Observation()
    return Mission(Config(),base,camera,log=lambda _:None)


def frame():
    rgb = np.zeros((40,40,3), dtype=np.uint8)
    rgb[12:28,12:28] = [220,5,220]
    depth = np.ones((40,40))
    K = np.array([[100.,0,20],[0,100.,20],[0,0,1.]])
    return rgb, depth, K


def test_color_depth_detection_and_rejection():
    rgb, depth, K = frame()
    cfg = Config(depth_stride=1,cam_pitch_deg=0,cam_forward_m=0,cam_height_m=.2)
    xy = detect_person(rgb,depth,K,cfg)
    assert xy == pytest.approx((1.,.005))
    assert detect_person(rgb,np.full_like(depth,np.nan),K,cfg) is None
    rgb[12:28,12:28] = [255,30,0]
    assert detect_person(rgb,depth,K,cfg) is None


def test_search_uses_observation_in_startup_frame(monkeypatch):
    from firebot.isaac import person
    monkeypatch.setattr(person,'detect_person',lambda *args: np.array([2.,0.]))
    mission = search_mission()
    mission.pose.theta = np.pi/2
    camera = mission.camera
    runtime = SimpleNamespace(time=lambda:0.)
    assert acquire_person(mission,camera,runtime,.45,lambda _:None) == pytest.approx((0.,1.55))


def test_missing_person_fails_after_bounded_search(monkeypatch):
    from firebot.isaac import person
    monkeypatch.setattr(person,'detect_person',lambda *args: None)
    mission = search_mission()
    with pytest.raises(MissionFailed,match='not visible'):
        acquire_person(mission,mission.camera,SimpleNamespace(time=lambda:0.),.45,lambda _:None,max_moves=0)
    assert mission.base.turn.call_count == 4


def test_viewpoint_never_routes_through_unknown_or_obstacles():
    from firebot.isaac.person import next_viewpoint, exploration_mask
    mission = search_mission()
    assert next_viewpoint(mission,[(0.,0.)]) is None
    mission.grid.state[:] = FREE
    mission.grid.mark((.3,0.),OCC)
    target = next_viewpoint(mission,[(0.,0.)])
    assert target is not None
    assert mission.grid.segment_clear(exploration_mask(mission),(0.,0.),target)
    assert .30 <= np.linalg.norm(target) <= .55


def test_person_found_after_exploration_records_home_route(monkeypatch):
    from firebot.isaac import person
    mission = search_mission()
    mission.grid.state[:] = FREE
    mission.base.move.side_effect = lambda distance: (distance,False)
    detections = iter([None]*4 + [np.array([1.,0.])])
    monkeypatch.setattr(person,'detect_person',lambda *args: next(detections))
    monkeypatch.setattr(person,'next_viewpoint',lambda *args:(.4,0.))
    acquire_person(mission,mission.camera,SimpleNamespace(time=lambda:0.),.45,lambda _:None)
    assert mission.exploration_moves == 1
    assert mission.search_path[0] == (0.,0.)
    assert mission.search_path[-1] == pytest.approx((.4,0.))
    assert mission.goal is not None
    assert np.linalg.norm(np.asarray(mission.goal)-np.asarray(mission.person_observation)) == pytest.approx(.45)


def test_rejected_route_does_not_repeat_full_scan(monkeypatch):
    from firebot.isaac import person
    mission = search_mission()
    mission.grid.state[:] = FREE
    mission.base.move.side_effect = lambda distance: (distance,False)
    detections = iter([None]*7 + [np.array([1.,0.])])
    monkeypatch.setattr(person,'detect_person',lambda *args:next(detections))
    monkeypatch.setattr(person,'next_viewpoint',lambda *args:(.4,0.))
    mission.grid.segment_clear=Mock(side_effect=[False,True])
    messages=[]
    acquire_person(mission,mission.camera,SimpleNamespace(time=lambda:0.),.45,messages.append)
    assert sum('Initial search: turn' in msg for msg in messages) == 4
    assert sum('Initial 360 complete' in msg for msg in messages) == 1
    mission.base.move.assert_called_once()
    assert mission.exploration_moves == 1


def test_search_time_budget_prevents_motion(monkeypatch):
    mission = search_mission()
    clock = iter([0.,221.])
    with pytest.raises(MissionFailed,match='time limit'):
        acquire_person(mission,mission.camera,SimpleNamespace(time=lambda:next(clock)),.45,lambda _:None)
    mission.base.turn.assert_not_called()
    mission.base.move.assert_not_called()


def test_blocked_direct_approach_tries_another_side():
    from firebot.isaac.person import plan_person_approach
    mission = search_mission()
    mission.person_observation=(2.,0.)
    mission.scan=Mock()
    mission.plan=Mock(side_effect=[MissionFailed('blocked'),[(0.,0.),(1.6,-.2)]])
    goal=plan_person_approach(mission,.45,lambda _:None)
    assert mission.plan.call_count == 2
    assert goal != pytest.approx((1.55,0.))
    assert np.linalg.norm(np.array(goal)-[2.,0.]) == pytest.approx(.45)


def test_no_reachable_person_approach_fails():
    from firebot.isaac.person import plan_person_approach
    mission = search_mission()
    mission.person_observation=(2.,0.)
    mission.scan=Mock()
    mission.plan=Mock(side_effect=MissionFailed('blocked'))
    with pytest.raises(MissionFailed,match='no reachable stopping'):
        plan_person_approach(mission,.45,lambda _:None)
    assert mission.plan.call_count == 12
