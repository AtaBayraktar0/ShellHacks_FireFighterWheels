from types import SimpleNamespace
from unittest.mock import Mock
import numpy as np
import pytest
from firebot.isaac.dashboard import Dashboard, depth_rgb, map_rgb, restart_arguments
from firebot.config import Config
from firebot.grid import OccupancyGrid


def test_depth_invalid_pixels_are_black_and_ranges_have_different_colors():
    image = depth_rgb(np.array([[np.nan,0,np.inf],[.2,1.,3.]]))
    assert not image[0].any()
    assert not np.array_equal(image[1,0],image[1,2])


def test_map_render_does_not_change_navigation_grid():
    grid = OccupancyGrid(Config())
    before = grid.state.copy()
    mission = SimpleNamespace(grid=grid,planned=[(0,0),(1,0)],goal=(1,0),pose=SimpleNamespace(xy=(0,0)))
    image = map_rgb(mission,[[0,0,0,0],[1,.1,0,0]],(.1,0,0))
    assert image.shape == (400,480,3)
    assert np.array_equal(grid.state,before)


def test_pause_pumps_ui_without_physics_steps_then_resumes():
    dashboard = Dashboard.__new__(Dashboard)
    dashboard.paused=True
    dashboard.stopped=False
    dashboard.refresh=Mock()
    dashboard.rt=Mock()
    dashboard.rt.app.is_running.return_value=True
    dashboard.rt.app.update.side_effect=lambda: setattr(dashboard,'paused',False)
    dashboard.gate()
    dashboard.rt.app_utils.pause.assert_called_once()
    dashboard.rt.app_utils.play.assert_called_once()
    dashboard.rt.step.assert_not_called()


def test_stop_interrupts_navigation():
    dashboard = Dashboard.__new__(Dashboard)
    dashboard.paused=False
    dashboard.stopped=True
    with pytest.raises(KeyboardInterrupt):
        dashboard.gate()


def test_reset_preserves_goal_except_when_changing_scenario():
    args=['--dashboard','--person-goal','--layout','flame','--goal','1.8','.7','--output','old']
    same=restart_arguments(args,'flame','flame','new')
    changed=restart_arguments(args,'flame','room','new')
    assert '--goal' in same and '--goal' not in changed
    assert '--person-goal' in changed and 'old' not in changed
