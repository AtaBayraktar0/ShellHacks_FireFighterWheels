# Return recovery validation — 2026-09-27

Implemented bounded Isaac return recovery with full scans, observed-space home
routing, and reachable viewpoints that can be accessed through old corridors.
Every leg is checked against a fresh observation. Unknown space is inflated for
the entire robot footprint; obstacle/fire/edge margins remain active, with one
extra grid cell of clearance. Assumed obstacle depth is omitted only in this
recovery mask; configuration is preserved. Control and physics failures are
not caught as recoverable route failures. Partial return history is preserved.

Validation: 105 tests passed, 1 platform-specific serial test skipped on Windows.
Tests cover successful recovery, viewpoint-then-home recovery, corner routing,
unknown-space rejection, full footprint clearance, fresh obstruction rejection,
time/attempt bounds, history/config preservation, and fatal control errors.

Actual Isaac 6.1 RGB-D demo, person goal, return obstacle, seed 0:
3 recovery moves, 4 scanning/planning attempts; no footprint violation.
Minimum measured conservative box gap: 0.0592 m. The mission DID NOT RETURN HOME:
it exhausted reachable observed-free viewing positions and exited with failure.
Final estimated-position error against evaluation truth was about 0.117 m.
Even the final measured-surface map without unknown inflation had no home route.
This is a safe bounded stop in this trial, not proof that a physical route does
not exist. Successful return in this demo remains unresolved; mapping/localization
needs further work. The extra clearance is a heuristic, not a formal error bound.

An earlier experimental surface-only mask caused a footprint violation and was
rejected. Its trial report is included as experimental-rejected.json for traceability.
The final implementation requires observed space around the full footprint.
No physical robot trial was performed. The Raspberry Pi entry point is unchanged.

Command used (from project root, with Isaac python.bat):
python.bat -m firebot.run_isaac --headless --layout demo --sensor rgbd --person-goal --return-obstacle --seed 0 --max-seconds 480 --output <run-folder>


# Validation of the unified project

## Random obstacle on return — 2026-09-27

- Added an optional dashboard checkbox and `--return-obstacle`. One seeded
  yellow box is spawned on the upcoming return path after actual return travel.
  Scene truth places the scenario obstacle, but the robot's map is updated only
  through its existing sensor observations. Spawn skips when no suitable point
  exists. Log/result records capture position, timing and outcome.
- CPU suite: **93 passed, 1 skipped**. New tests verify delayed one-time spawn,
  clearance from the robot, seed reproducibility, and skipping occupied paths.
- Native Isaac UI check passed: checkbox initializes, toggles, and retains its
  selection when reset is requested.
- Isaac RGB-D person mission, flame layout, person (1.8, 0.7), seed 0:
  obstacle spawned, return route replanned, mission passed (exit 0), home error
  0.01853 m, no footprint violation.
- Isaac RGB-D person mission, demo layout, seed 0: obstacle spawned, robot
  attempted replanning, then stopped with no safe path home (exit 1). No footprint
  violation. This is an expected possible outcome of blocking a narrow route;
  enabling this disturbance does not guarantee a successful return.

## Single initial scan correction — 2026-09-27

- Fixed the repeated full scan after an exploration route failed its fresh
  obstacle check. Only the initial search performs four 90-degree chassis turns.
  Subsequent exploration uses camera pans and route selection.
- **90 passed, 1 skipped**, including a regression that rejects the first route
  and verifies one initial scan followed by an exploration move.
- Actual Isaac RGB-D demo mission passed (exit 0). Log confirms four initial
  quarter turns, a rejected route, then another route choice without a second
  full scan; the robot moved, detected the person, and returned home.

## Person exploration recovery — 2026-09-27

- Person search now scans four quarter-turn headings (one 360-degree sweep), selects reachable observed-free viewing
  positions, moves up to eight times within a 220-second simulated budget, and
  retries alternate stopping positions when the direct approach is blocked.
- Demo layout regression: the person was initially hidden by the scene. The
  robot made **1 exploration move**, detected the person, selected a +60 degree
  alternate approach, replanned once, and completed the mission successfully.
  Approach error was 0.03335 m, person-center distance 0.49868 m, and home error
  0.03591 m with no footprint violation.
- CPU suite after exploration changes: **89 passed, 1 skipped**. The skipped
  test requires a POSIX serial terminal.

## Live simulation dashboard — 2026-09-27

- Native Isaac UI with RGB, depth, occupancy map, planned/true paths, estimated
  and true positions, phase, time, replan count, and mission messages.
- Start/Pause/Resume, Stop, and Reset/scenario selection. Reset launches a fresh
  process and writes a new run folder; changed layouts reset the goal placement.
- **84 passed, 1 skipped** in the CPU regression suite. Dashboard tests cover
  depth validity, map rendering without grid mutation, pause and stop behavior,
  and reset command construction.
- Visually inspected the dashboard during an actual Isaac RGB-D person mission.
  That mission passed with 0.00170 m approach error and 0.01121 m home error.
- A second Isaac mission exercised Start, Pause, and Resume through the button
  callbacks. Verified physics time stayed fixed during pause; mission passed
  after resuming. Full Reset process relaunch was not exercised in this check.
- Ground truth feeds the display/evaluation only. This update adds no human
  recognition or exploration capability beyond the person proxy described below.

## Simulated person goal — 2026-09-27

- Added `--person-goal` for Isaac RGB-D missions with a stationary, collidable
  human-shaped miniature. Navigation uses clothing-color and depth observations;
  the scene placement is used for spawning and evaluation. This is not a trained
  human-recognition system and does not track moving people.
- CPU suite: **79 passed, 1 skipped**. Tests cover depth/color rejection,
  startup-frame goal conversion, and bounded failure when no person is visible.
- Actual Isaac run: `--headless --layout flame --sensor rgbd --person-goal
  --goal 1.8 0.7`: **passed, exit 0**, no footprint violation. Approach-point error
  0.00799 m; distance between robot and person centers at arrival 0.48783 m;
  return-home error 0.02922 m. One replan.
- This is one controlled scene, not validation across lighting, occlusion,
  multiple people or cluttered layouts. The robot scans from its starting
  position; it does not explore rooms to locate a hidden person.

## Persistent mission logs — version 0.2.2, 2026-09-27

- Added automatic rotating JSON-line logs for the main Raspberry Pi mission,
  including configuration, estimated pose/routes, marker search, Arduino events,
  exit status, and error tracebacks. Default destination is `runs/logs`;
  `--log-dir` selects a fixed writable deployment directory.
- Regression suite: **76 passed, 1 skipped** with OpenCV 4.8.1. New tests verify
  successful mission records, camera failure logging with hardware cleanup,
  rotation limits, and distinct identifiers across runs.
- This update does not change motion control. No additional physical Pi or
  Isaac trials were performed for the logging update; prior results are below.
- Logging covers `firebot mission`. Other commands retain their existing output
  behavior. Camera video is not recorded, and abrupt power loss can lose recent
  filesystem writes. One mission process should run at a time.

## Integrity fixes — version 0.2.1, 2026-09-27

Fixed fixed-camera marker yaw, retained the startup coordinate frame through
marker search turns (with and without IMU), validated finite marker settings and
family/ID ranges, restored OpenCV 4.6 compatibility, and corrected marker plotting.
Search timeout includes the first scan; failure cleanup stops and recenters the camera.
The installer now exercises AprilTag detection through `firebot doctor --markers`.

Isaac raycasts now classify random-layout flames, clearance checks use the actual
rectangular flame footprint, and the process exit code reflects the result.
Isaac explicitly rejects unsupported AprilTag missions.

- Final suite: **73 passed, 1 skipped**, Python 3.12.14, NumPy 1.26.4,
  OpenCV contrib 4.8.1, pytest 9.1.1. The skipped module requires POSIX serial terminals.
- OpenCV 4.6: the earlier 71-test suite passed and marker diagnostics passed.
- Built version 0.2.1 wheel, installed outside the source tree, and completed
  a CPU round trip with zero collisions.
- Pi installer passed `bash -n`.
- Actual Isaac 6.1 runtime, random seed 0, raycast full mission: passed, exit 0;
  goal error 0.01024 m, home error 0.02143 m, no footprint violation.
- Actual Isaac RGB-D demo smoke test: passed, exit 0; forward motion 0.11939 m,
  turn 44.28 degrees, no footprint violation.
- Deliberate Isaac timeout: failed as expected, exit 1.
- RGB-D random seed 0 smoke test stopped near an obstacle and correctly failed
  with exit 1; the demo layout was used for the unobstructed movement check.

Nested project copies and old build artifacts were preserved under workspace
`work/integrity-fix-backup`, outside this single project root. Existing `runs`
were retained locally; the distributable ZIP excludes runs, caches and build artifacts.

This is targeted regression validation, not a rerun of the previous 15-trial
study. Historical reports remain unchanged. Real Raspberry Pi installation,
physical marker navigation, motors, camera and firmware remain unverified.
Marker acquisition produces a fixed waypoint, not continuous visual tracking.

## Historical validation before these fixes

Validated on Windows AMD64, Python 3.12.14, on 2026-09-27.

- Combined pytest suite: **54 passed, 1 skipped**. The skipped module contains
  POSIX pseudo-terminal serial tests and requires Linux/macOS.
- Both original CPU test suites and Isaac adapter math tests are included.
- Added regressions for missing configuration, motion authorization,
  calibration gating, serial/motor cleanup when camera startup fails, and CLI
  argument restoration.
- Built the installable Python wheel and installed it into an isolated target
  directory. Ran commands from outside the source tree.
- Installed-package `doctor` passed for NumPy, OpenCV and pyserial.
- Installed-package `mission --sim` completed its round trip with zero collisions.
- Installed-package pulse `simulate` completed; `--block-return` detected the
  blocked return route as expected.
- Installed-package Isaac help loaded without importing the Isaac runtime.
- Verified packaged pulse config and Isaac `.kit` resource are present.
- Both Pi shell scripts passed `bash -n`; both use LF line endings.
- Verified the pinned RealSense SDK tag provides the referenced USB udev rules.

Test dependencies: NumPy 2.5.3, OpenCV 4.14.0, pyserial 3.5, pytest 9.1.1.
The Pi installer instead uses Pi OS native NumPy/OpenCV/serial packages.

Not executed here: apt installation on Raspberry Pi OS, ARM RealSense source
compilation, USB camera capture, physical motors/gyro/sonar, Arduino compilation
or upload, and full Isaac Sim physics/rendering. Those need their target
hardware/runtimes. Run `python -m pytest -q` on the Pi for the POSIX tests and
follow README.md for physical commissioning.
