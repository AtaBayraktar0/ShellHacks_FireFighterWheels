"""Bounded, observation-only return recovery for the Isaac mission runner."""
import math
from collections import deque
import numpy as np
from firebot.astar import NEIGHBORS, astar, smooth, split_long
from firebot.grid import FREE, UNKNOWN, OCC, dilate
from firebot.rescue_mission import MissionFailed, RouteUnavailable


def recovery_mask(mission):
    # Observed surfaces retain full obstacle/fire inflation. Unknown centers
    # remain forbidden; assumed depth must not inflate into measured corridors.
    unknown = mission.grid.state != FREE
    mission.grid.clear_disk(unknown, mission.pose.xy, mission.cfg.robot_radius_m)
    # Reserve one extra cell for map quantization and time-based drive error.
    clearance = mission.cfg.clearance_m + mission.grid.res
    radius = math.ceil((mission.cfg.robot_radius_m + clearance)/mission.grid.res)
    return (mission.grid.blocked_mask(clearance=clearance, assumed_depth=0.) |
            dilate(unknown, radius))


def route(mission, mask, target):
    grid = mission.grid
    start, end = grid.cell(mission.pose.xy), grid.cell(target)
    if start is None or end is None or mask[start[1], start[0]]:
        return None
    cells = astar(mask, start, end)
    if not cells:
        return None
    points = [mission.pose.xy] + [grid.center(c) for c in cells[1:]]
    if grid.segment_clear(mask, points[-1], target):
        points.append(target)
    return split_long(smooth(points, lambda a,b:grid.segment_clear(mask,a,b)),
                      mission.cfg.max_segment_m)


def viewing_route(mission, mask, visited):
    """Search the connected observed floor, including routes via old viewpoints."""
    grid = mission.grid
    start = grid.cell(mission.pose.xy)
    if start is None or mask[start[1],start[0]]:
        return None
    queue, seen = deque([start]), {start}
    candidates = []
    while queue:
        x,y = queue.popleft()
        point = grid.center((x,y))
        novelty = min(math.dist(point,p) for p in visited)
        if novelty >= .25 and math.dist(point,mission.pose.xy) >= .30:
            r = math.ceil(.6/grid.res)
            patch = grid.state[max(0,y-r):y+r+1,max(0,x-r):x+r+1]
            gain = float(np.mean(patch == UNKNOWN))
            score = 2*gain + min(novelty,.6) - .15*math.dist(point,mission.start)
            candidates.append((score,point))
        for dx,dy,_ in NEIGHBORS:
            nx,ny=x+dx,y+dy
            if not (0<=nx<grid.nx and 0<=ny<grid.ny) or (nx,ny) in seen or mask[ny,nx]:
                continue
            if dx and dy and (mask[y,nx] or mask[ny,x]):
                continue
            seen.add((nx,ny))
            queue.append((nx,ny))
    if not candidates:
        return None
    return route(mission,mask,max(candidates,key=lambda p:p[0])[1])


def return_with_exploration(mission, runtime, log, max_moves=24, recovery_seconds=240.):
    mission.return_recovery_moves = 0
    mission.return_recovery_attempts = 0
    try:
        mission.return_trip()
        return
    except RouteUnavailable as exc:
        log(f'Return route blocked: {exc}; searching for another safe way home')
    deadline = runtime.time()+recovery_seconds
    visited = [mission.pose.xy]
    def check_time():
        if runtime.time() >= deadline:
            raise MissionFailed('Return exploration time budget exhausted')
    for attempt in range(max_moves+1):
        check_time()
        mission.return_recovery_attempts += 1
        mission.phase = 'return exploration'
        # Scan at each heading using camera pans to avoid FOV gaps.
        for _ in range(4):
            check_time()
            mission.scan()
            check_time()
            mission.turn_to_heading(mission.pose.theta+math.pi/2)
        check_time()
        mask = recovery_mask(mission)
        path = route(mission,mask,mission.start)
        home = path is not None
        if not home:
            path = viewing_route(mission,mask,visited)
        if path is None:
            raise MissionFailed('Return exploration exhausted reachable observed-free viewing positions')
        if math.dist(mission.pose.xy,mission.start) <= mission.cfg.goal_tolerance_m:
            return
        if attempt == max_moves:
            break
        target = path[-1]
        mission.planned = path
        mission.phase = 'return alternate route' if home else 'return exploration'
        log('Found an observed route home' if home else
            f'Return exploration: viewing position ({target[0]:.2f}, {target[1]:.2f})')
        moved = False
        for waypoint in path[1:]:
            check_time()
            distance = math.dist(mission.pose.xy,waypoint)
            if distance < .02:
                continue
            mission.turn_to_heading(math.atan2(waypoint[1]-mission.pose.y,waypoint[0]-mission.pose.x))
            mission.look_ahead()
            check_time()
            if not mission.grid.segment_clear(recovery_mask(mission),mission.pose.xy,waypoint):
                log('Recovery route changed; rescanning before further motion')
                break
            stopped = mission.drive(distance)
            moved = True
            mission.driven_back.append(mission.pose.xy)
            mission._send_state()
            if stopped:
                ahead=mission.cfg.robot_front_m+mission.cfg.sonar_stop_m
                mission.grid.mark((mission.pose.x+ahead*math.cos(mission.pose.theta),
                                   mission.pose.y+ahead*math.sin(mission.pose.theta)),OCC)
                log('Return recovery proximity stop; rescan')
                break
        mission.return_recovery_moves += int(moved)
        visited.append(mission.pose.xy)
        if math.dist(mission.pose.xy,mission.start) <= mission.cfg.goal_tolerance_m:
            return
    raise MissionFailed('Return exploration move budget exhausted; no verified route home')
