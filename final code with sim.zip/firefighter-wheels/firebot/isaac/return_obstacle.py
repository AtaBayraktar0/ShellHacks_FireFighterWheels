"""Seeded scenario event; scene truth never updates the robot's map directly."""
import math
import random
from .math_utils import rectangle_gap


class ReturnObstacle:
    def __init__(self, path, seed, cfg, boxes, flame, log):
        self.path = list(reversed(path))
        self.rng = random.Random(seed)
        self.trigger_distance = self.rng.uniform(.15,.30)
        self.cfg, self.boxes, self.flame, self.log = cfg, boxes, flame, log
        self.previous = None
        self.travelled = 0.
        self.event = {'status':'pending','seed':seed,'trigger_distance_m':self.trigger_distance}

    def update(self, position, now, spawn):
        if self.event['status'] != 'pending':
            return
        if self.previous is not None:
            self.travelled += math.dist(position,self.previous)
        self.previous = position
        if self.travelled < self.trigger_distance or not self.path:
            return
        nearest = min(range(len(self.path)),key=lambda i:math.dist(position,self.path[i]))
        candidates=[]
        arc=0.
        last=self.path[nearest]
        for point in self.path[nearest+1:]:
            arc += math.dist(last,point)
            last=point
            if arc > 1.2:
                break
            if arc < .7 or math.dist(point,position) < .65 or math.hypot(*point) < .4:
                continue
            x,y=point
            half=.075
            rect=(x-half,y-half,x+half,y+half)
            if not (self.cfg.x_min+.1 < rect[0] and rect[2] < self.cfg.x_max-.1 and
                    self.cfg.y_min+.1 < rect[1] and rect[3] < self.cfg.y_max-.1):
                continue
            if any(rectangle_gap(x,y,.16,b) < 0 for b in self.boxes):
                continue
            if self.flame and math.dist(point,self.flame) < .3:
                continue
            candidates.append(rect)
        if not candidates:
            return  # Try again farther along; never spawn on top of the robot.
        rect=self.rng.choice(candidates)
        spawn(rect)
        self.event.update(status='spawned',time_s=now,bounds=list(rect),
                          robot_position=list(position),return_distance_m=self.travelled)
        self.log(f'Return obstacle appeared ahead at ({(rect[0]+rect[2])/2:.2f}, {(rect[1]+rect[3])/2:.2f}); robot must detect and replan')

    def finish(self):
        if self.event['status']=='pending':
            self.event.update(status='skipped',reason='No suitable clear point ahead before return ended')
            self.log('Return obstacle skipped: no suitable clear point ahead')
