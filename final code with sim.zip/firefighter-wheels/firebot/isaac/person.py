"""Simulation-only rescue dummy detection; clothing color is not human recognition."""
import math
import numpy as np
from firebot.perception import camera_to_robot
from firebot.rescue_mission import MissionFailed
from firebot.grid import FREE, UNKNOWN, OCC
from .math_utils import optical_points


def detect_person(rgb, depth, K, cfg, yaw=0.):
    # The procedural dummy wears saturated magenta, distinct from the fire prop.
    rgb = np.asarray(rgb, dtype=float)
    r, g, b = rgb[..., 0], rgb[..., 1], rgb[..., 2]
    mask = (r > 70) & (b > 70) & (r > 1.6*g) & (b > 1.6*g)
    points = optical_points(depth, K, cfg, mask)
    if len(points) < 8:
        return None
    points = camera_to_robot(points, cfg, yaw)
    points = points[(points[:, 2] > .04) & (points[:, 2] < .65)]
    return np.median(points[:, :2], axis=0) if len(points) >= 8 else None


def exploration_mask(mission):
    """Use normal obstacle/fire margins and only observed floor for exploration."""
    # The robot already occupies this disk. Preserve obstacle/edge inflation.
    known_mask = mission.grid.state != FREE
    mission.grid.clear_disk(known_mask, mission.pose.xy, mission.cfg.robot_radius_m + .05)
    mask = mission.grid.blocked_mask() | known_mask
    mission.grid.block_edges(mask)
    return mask


def next_viewpoint(mission, visited):
    """Choose a short visible free leg near unknown space, without target truth."""
    grid = mission.grid
    mask = exploration_mask(mission)
    candidates = []
    for iy, ix in np.argwhere(~mask):
        point = grid.center((int(ix),int(iy)))
        distance = math.dist(mission.pose.xy,point)
        novelty = min(math.dist(point,p) for p in visited)
        if not .30 <= distance <= .55 or novelty < .25:
            continue
        if not grid.segment_clear(mask,mission.pose.xy,point):
            continue
        radius = int(.55/grid.res)
        patch = grid.state[max(0,iy-radius):iy+radius+1,max(0,ix-radius):ix+radius+1]
        gain = float(np.mean(patch == UNKNOWN))
        candidates.append((gain + .6*novelty,point))
    return max(candidates,key=lambda item:item[0])[1] if candidates else None


def acquire_person(mission, camera, runtime, stop_distance, log, max_moves=8, search_seconds=220.):
    """Scan, move through observed free floor, and repeat until found or bounded out."""
    # A found person does not justify squeezing through zero-clearance routes.
    mission.cfg.fallback_margins = ()
    deadline = runtime.time() + search_seconds
    visited = [mission.pose.xy]
    mission.search_path = [mission.pose.xy]
    mission.exploration_moves = 0
    for move in range(max_moves+1):
        initial_scan = move == 0
        mission.phase = 'searching for person' if initial_scan else 'exploring for person'
        # Only the initial search rotates the chassis through 360 degrees.
        # Later checks pan the camera while selecting the next exploration leg.
        yaws = (0.,)*4 if initial_scan else (0., math.pi/3, -math.pi/3)
        for yaw in yaws:
            if runtime.time() >= deadline:
                raise MissionFailed('Person search reached its exploration time limit')
            observation = camera.observe(yaw)
            mission.grid.update(observation,mission.pose)
            mission._send_grid()
            xy = detect_person(camera.last_rgb, camera.last_depth, camera.K, mission.cfg, yaw)
            if xy is not None:
                distance = float(np.linalg.norm(xy))
                if distance <= stop_distance:
                    raise MissionFailed('Person is already within the stopping distance')
                local = xy * (1. - stop_distance/distance)
                pose = mission.pose
                c, s = math.cos(pose.theta), math.sin(pose.theta)
                mission.person_observation = (pose.x+c*xy[0]-s*xy[1],pose.y+s*xy[0]+c*xy[1])
                goal = (pose.x+c*local[0]-s*local[1], pose.y+s*local[0]+c*local[1])
                mission.goal = goal
                log(f'Person proxy detected at {distance:.2f} m after {mission.exploration_moves} exploration moves; approach goal {goal}')
                return goal
            if initial_scan:
                log('Initial search: turn 90 degrees')
                mission.turn_to_heading(mission.pose.theta + math.pi/2)
        camera.pan(0.)
        if initial_scan:
            log('Initial 360 complete; entering exploration')
        mission.phase = 'exploring for person'
        if move == max_moves:
            break
        target = next_viewpoint(mission,visited)
        if target is None:
            raise MissionFailed('Person not visible and no new reachable viewing position on observed floor')
        mission.phase = 'exploring for person'
        mission.planned = [mission.pose.xy,target]
        log(f'Exploring: moving to viewing position ({target[0]:.2f}, {target[1]:.2f})')
        mission.turn_to_heading(math.atan2(target[1]-mission.pose.y,target[0]-mission.pose.x))
        mission.look_ahead()
        visited.append(target)
        if runtime.time() >= deadline:
            raise MissionFailed('Person search reached its exploration time limit')
        if not mission.grid.segment_clear(exploration_mask(mission),mission.pose.xy,target):
            log('Viewing route blocked; selecting another exploration route without a full scan')
            continue
        stopped = mission.drive(math.dist(mission.pose.xy,target))
        mission.search_path.append(mission.pose.xy)
        mission.exploration_moves += 1
        visited.append(mission.pose.xy)
        if stopped:
            ahead = mission.cfg.robot_front_m + mission.cfg.sonar_stop_m
            mission.grid.mark((mission.pose.x+ahead*math.cos(mission.pose.theta),
                               mission.pose.y+ahead*math.sin(mission.pose.theta)),OCC)
            log('Exploration stopped by proximity sensor; rescan')
    raise MissionFailed('Person not visible after bounded exploration')


def plan_person_approach(mission, stop_distance, log):
    """Try other sides if the direct stopping point is obstructed in the map."""
    mission.phase = 'planning person approach'
    mission.scan()
    px, py = mission.person_observation
    bearing = math.atan2(mission.pose.y-py,mission.pose.x-px)
    for offset in [0,30,-30,60,-60,90,-90,120,-120,150,-150,180]:
        angle = bearing + math.radians(offset)
        goal = (px+stop_distance*math.cos(angle),py+stop_distance*math.sin(angle))
        try:
            path = mission.plan(goal)
        except MissionFailed:
            continue
        mission.goal, mission.planned = goal,path
        mission._send_state()
        log(f'Planned person approach from {offset:+d} degrees: {goal}')
        return goal
    raise MissionFailed('Person found, but no reachable stopping position around them')
