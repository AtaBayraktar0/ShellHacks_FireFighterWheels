"""Native Isaac dashboard. Ground truth is display-only, never navigation input."""
import time
import numpy as np


def depth_rgb(depth, maximum=3.):
    import cv2
    valid = np.isfinite(depth) & (depth > 0)
    values = np.clip(np.nan_to_num(depth, nan=maximum, posinf=maximum)/maximum, 0, 1)
    rgb = cv2.applyColorMap((255*(1-values)).astype(np.uint8), cv2.COLORMAP_TURBO)[..., ::-1].copy()
    rgb[~valid] = 0
    return rgb


def map_rgb(mission, samples, truth):
    import cv2
    grid = mission.grid
    palette = np.array([[105,115,130], [235,239,244], [35,40,49], [255,95,35]], np.uint8)
    image = cv2.resize(palette[grid.state], (480,400), interpolation=cv2.INTER_NEAREST)
    image = np.flipud(image).copy()
    def pixel(xy):
        return (round((xy[0]-grid.x0)/(grid.nx*grid.res)*479),
                round(399-(xy[1]-grid.y0)/(grid.ny*grid.res)*399))
    def route(points, color):
        if len(points)>1:
            cv2.polylines(image,[np.array([pixel(p) for p in points],np.int32)],False,color,2)
    route(mission.planned,(30,180,65))
    route([p[1:3] for p in samples[::max(1,len(samples)//1500)]],(205,60,230))
    cv2.circle(image,pixel(mission.goal),6,(30,180,65),2)
    cv2.circle(image,pixel((0.,0.)),6,(30,80,220),2)
    cv2.circle(image,pixel(truth[:2]),5,(205,60,230),-1)
    cv2.circle(image,pixel(mission.pose.xy),4,(30,140,250),-1)
    return image


class Dashboard:
    def __init__(self, runtime, camera, layout, enable_return_obstacle=False):
        import omni.ui as ui
        self.rt, self.camera = runtime, camera
        self.mission = None
        self.paused = True
        self.stopped = False
        self.restart = False
        self.finished = False
        self.last_update = 0.
        self.layouts = ['flame','demo','room','random']
        self.providers = [ui.ByteImageProvider() for _ in range(3)]
        self.window = ui.Window('Rescue mission dashboard', width=700, height=760)
        with self.window.frame:
            with ui.VStack(spacing=5):
                ui.Label('RESCUE MISSION  |  SIMULATION', height=24)
                self.status = ui.Label('Ready - press Start', height=24)
                with ui.HStack(height=30,spacing=6):
                    self.toggle = ui.Button('Start',clicked_fn=self.toggle_pause)
                    ui.Button('Stop',clicked_fn=self.stop)
                    ui.Button('Reset / apply scenario',clicked_fn=self.reset)
                    self.scenario = ui.ComboBox(self.layouts.index(layout),*self.layouts)
                ui.Label('Scenario selection takes effect on Reset. Person mode is preserved.',height=20)
                with ui.HStack(height=20):
                    self.obstacle_option = ui.SimpleBoolModel(enable_return_obstacle)
                    ui.CheckBox(model=self.obstacle_option,width=24)
                    self.obstacle_status = ui.Label('Random obstacle on return (choose before retracing starts)')
                with ui.HStack(height=160,spacing=8):
                    for title, provider in zip(['Color camera','Depth: near red / far blue / invalid black'],self.providers[:2]):
                        with ui.VStack():
                            ui.Label(title,height=20)
                            ui.ImageWithProvider(provider)
                self.camera_status = ui.Label('Waiting for camera frames',height=20)
                ui.Label('Robot map: gray unknown / white free / dark obstacle / orange fire',height=20)
                ui.ImageWithProvider(self.providers[2],height=230)
                ui.Label('Green planned route + goal | Magenta actual trajectory | Blue estimated pose',height=20)
                self.metrics = ui.Label('',height=45,word_wrap=True)
                self.message = ui.Label('',height=35,word_wrap=True)

    def toggle_pause(self):
        if not self.finished:
            self.paused = not self.paused
            self.toggle.text = 'Resume' if self.paused else 'Pause'

    def stop(self):
        self.stopped = True

    def reset(self):
        self.restart = True
        self.stopped = True

    def selected_layout(self):
        return self.layouts[self.scenario.model.get_item_value_model().as_int]

    def gate(self):
        # Keep processing UI while physics is paused, preserving simulated time.
        if self.paused and not self.stopped:
            self.rt.app_utils.pause()
            while self.paused and not self.stopped and self.rt.app.is_running():
                self.refresh()
                self.rt.app.update()
                time.sleep(.02)
            if self.rt.app.is_running() and not self.stopped:
                self.rt.app_utils.play()
        if self.stopped or not self.rt.app.is_running():
            raise KeyboardInterrupt('Dashboard stop/reset')

    def log(self, text):
        self.message.text = text

    @staticmethod
    def put(provider, rgb):
        alpha = np.full((*rgb.shape[:2],1),255,np.uint8)
        rgba = np.ascontiguousarray(np.concatenate((rgb.astype(np.uint8),alpha),axis=2))
        provider.set_bytes_data(rgba.ravel().tolist(),[rgb.shape[1],rgb.shape[0]])

    def refresh(self, force=False):
        if not force and time.monotonic()-self.last_update < .2:
            return
        self.last_update = time.monotonic()
        event = getattr(self.rt,'return_obstacle',None)
        if event:
            self.obstacle_status.text = 'Return obstacle: ' + event.event['status']
        camera = self.camera
        if hasattr(camera,'sensor'):
            rgb,_ = camera.sensor.get_data('rgb')
            depth,_ = camera.sensor.get_data('distance_to_image_plane')
            if rgb is not None and depth is not None:
                rgb = rgb.numpy() if hasattr(rgb,'numpy') else np.asarray(rgb)
                depth = depth.numpy() if hasattr(depth,'numpy') else np.asarray(depth)
                depth = np.squeeze(depth)
                if depth.ndim == 2 and rgb.shape[:2] == depth.shape:
                    self.put(self.providers[0],rgb[...,:3][::2,::2])
                    self.put(self.providers[1],depth_rgb(depth[::2,::2],self.rt.cfg.max_range_m))
                    self.camera_status.text = 'Live simulated RGB-D | distance scale 0 to %.1f m' % self.rt.cfg.max_range_m
        else:
            self.camera_status.text = 'Raycast diagnostic mode: no rendered camera feed'
        if self.mission:
            truth = self.rt.pose()
            self.put(self.providers[2],map_rgb(self.mission,self.rt.samples,truth))
            if not self.finished:
                self.status.text = ('Paused | ' if self.paused else 'Running | ') + self.mission.phase
            self.metrics.text = (f'Simulation time: {self.rt.time()-self.rt.start_time:.1f} s | Replans: {self.mission.replans}\n'
                f'True XY: ({truth[0]:.2f}, {truth[1]:.2f}) m | Estimated XY: '
                f'({self.mission.pose.x:.2f}, {self.mission.pose.y:.2f}) m (updated at motion segments)')

    def finish(self, result):
        self.finished = True
        self.refresh(force=True)
        self.status.text = 'PASSED - returned home' if result.get('passed') else 'STOPPED / FAILED'
        self.message.text = result.get('error') or 'Use Reset to run again, or close Isaac to exit.'
        self.toggle.enabled = False


def restart_arguments(arguments, old_layout, new_layout, output):
    args = list(arguments)
    removed = [('--layout',1),('--output',1)]
    if new_layout != old_layout:
        removed.append(('--goal',2))
    for flag, count in removed:
        while flag in args:
            i=args.index(flag)
            del args[i:i+count+1]
        args = [arg for arg in args if not arg.startswith(flag+'=')]
    return args + ['--layout',new_layout,'--output',str(output)]
