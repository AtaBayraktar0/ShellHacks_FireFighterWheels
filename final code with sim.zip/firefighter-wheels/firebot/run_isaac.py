#!/usr/bin/env python3
"""Created by OpenAI Codex: standalone Isaac Sim 6.1 entry point.

Use Isaac Sim's python.sh/python.bat, not the system Python. Original hardware
runner is unchanged. New adapters and scene are isolated under isaac/.
"""
import argparse
import json
import math
import os
from pathlib import Path
import sys
import traceback

ROOT=Path(__file__).resolve().parent



def parser():
    p=argparse.ArgumentParser(description='CODEX fire robot — Isaac Sim 6.1')
    p.add_argument('--headless',action='store_true')
    p.add_argument('--dashboard',action='store_true',help='live camera/map dashboard with Start, Pause, Stop and Reset')
    p.add_argument('--sensor',choices=['rgbd','raycast'],default='rgbd')
    p.add_argument('--layout',choices=['demo','flame','room','random'],default='room')
    p.add_argument('--seed',type=int,default=0,help='random-map seed (replays the same arena)')
    p.add_argument('--config',type=Path)
    p.add_argument('--goal',type=float,nargs=2,metavar=('X','Y'))
    p.add_argument('--person-goal',action='store_true',help='spawn and visually find a stationary rescue dummy; RGB-D only')
    p.add_argument('--return-obstacle',action='store_true',help='spawn one random obstacle ahead during the return trip; --seed makes it repeatable')
    p.add_argument('--person-stop-distance',type=float,default=.45,help='robot center distance before observed person surface, metres')
    p.add_argument('--speed',type=float,default=.15,help='timed-drive speed in m/s')
    p.add_argument('--max-seconds',type=float,default=300.,help='simulation time limit')
    p.add_argument('--smoke-test',action='store_true',help='check camera, forward drive and turn, then exit')
    p.add_argument('--hold',action='store_true',help='keep GUI open after a successful run')
    p.add_argument('--save-stage',action='store_true')
    p.add_argument('--output',type=Path,default=Path.cwd()/'runs'/'isaac')
    return p


def main():
    args=parser().parse_args()
    if args.return_obstacle and args.smoke_test:
        raise SystemExit('--return-obstacle requires a full mission with a return trip')
    if args.dashboard and (args.headless or args.smoke_test):
        raise SystemExit('--dashboard requires a visible full mission; omit --headless and --smoke-test')
    if args.person_goal and (args.sensor != 'rgbd' or args.smoke_test):
        raise SystemExit('--person-goal requires --sensor rgbd and a full mission')
    if not math.isfinite(args.person_stop_distance) or args.person_stop_distance < .35:
        raise SystemExit('--person-stop-distance must be finite and at least 0.35 m')
    if not 0 < args.speed <= .3:
        raise SystemExit('--speed must be greater than 0 and at most 0.3 m/s')
    if not math.isfinite(args.max_seconds) or args.max_seconds <= 0:
        raise SystemExit('--max-seconds must be positive and finite')
    if args.headless and args.hold:
        raise SystemExit('--hold requires the GUI; omit it with --headless')
    args.output.mkdir(parents=True,exist_ok=True)
    # Bootstrap Kit before importing any omni/pxr/Isaac extensions.
    try:
        from isaacsim import SimulationApp
    except ImportError as exc:
        raise SystemExit('Run this script using Isaac Sim 6.1 python.sh (Linux) or python.bat (Windows).') from exc
    install=Path(os.environ['EXP_PATH']).resolve().parent
    extra_args=[
        '--ext-folder', str(install/'extscache'),
        '--ext-folder', str(install/'extsDeprecated'),
        '--ext-folder', str(install/'extsInternal'),
    ]
    app=SimulationApp({'headless':args.headless,'width':1280,'height':800,
                       'extra_args':extra_args},
                      experience=str(ROOT/'isaac'/'fire_robot.kit'))
    rt=base=camera=mission=dashboard=None
    result=dict(created_by='OpenAI Codex',target_isaac_version='6.1',
                sensor=args.sensor,layout=args.layout,seed=args.seed,
                mode='smoke' if args.smoke_test else 'mission',
                passed=False,mission_completed=False,error=None)
    code=1
    try:
        import numpy as np
        import isaacsim.core.experimental.utils.app as app_utils
        # Explicitly enable runtime dependencies before importing them.
        for extension in ['isaacsim.core.experimental.prims','isaacsim.core.simulation_manager',
                          'isaacsim.sensors.experimental.rtx']:
            app_utils.enable_extension(extension)
        from firebot.config import Config
        from firebot.geometry import dist,wrap
        from firebot.rescue_mission import Mission
        from firebot.isaac.runtime import Runtime
        from firebot.isaac.control import IsaacBase
        from firebot.isaac.sensors import RgbdCamera,RaycastCamera
        cfg=Config.load(args.config)
        if cfg.goal_mode != 'coordinate':
            raise ValueError('Isaac runner supports coordinate goals only; AprilTag mode requires the hardware camera')
        if args.layout == 'room':
            from firebot.isaac.room_layout import configure
            configure(cfg)
        elif args.layout == 'random':
            from firebot.isaac.random_layout import configure
            configure(cfg)
        if not cfg.use_imu:
            raise ValueError('Isaac runner requires use_imu=True; ideal physics yaw supplies the simulated gyro')
        if not cfg.edge_is_wall:
            raise ValueError('Isaac tabletop runner requires edge_is_wall=True')
        cfg.speed_mps=args.speed
        if args.goal:
            cfg.goal_xy=tuple(args.goal)
        result['config']=__import__('dataclasses').asdict(cfg)
        person_xy = tuple(cfg.goal_xy) if args.person_goal else None
        result['person_position'] = person_xy
        rt=Runtime(app,cfg,args.layout,args.max_seconds,args.seed,person_xy=person_xy)
        rt.stage.GetRootLayer().customLayerData={'creator':'OpenAI Codex','target':'Isaac Sim 6.1'}
        base=IsaacBase(rt,cfg)
        camera=RgbdCamera(rt,cfg) if args.sensor=='rgbd' else RaycastCamera(rt,cfg)
        base.camera=camera
        if args.dashboard:
            from firebot.isaac.dashboard import Dashboard
            dashboard = Dashboard(rt,camera,args.layout,enable_return_obstacle=args.return_obstacle)
            rt.dashboard = dashboard
        if not args.headless:
            from isaacsim.core.utils.viewports import set_camera_view
            set_camera_view(eye=[3.4,-3.6,3.2],target=[1.,0.,0.])
        if args.save_stage:
            rt.stage.GetRootLayer().Export(str((args.output/'codex_scene.usda').resolve()))
        def log(message):
            if dashboard:
                dashboard.log(message)
            print('[CODEX]',message,flush=True)
            with (args.output/'mission.log').open('a',encoding='utf-8') as stream:
                stream.write(message+'\n')
        (args.output/'mission.log').write_text('',encoding='utf-8')
        print('CODEX | Isaac Sim 6.1 | Physical wheel-joint control | '+args.sensor,flush=True)
        if args.smoke_test:
            obs=camera.observe(0.)
            if len(obs.floor)==0 or len(obs.obstacles)==0:
                raise RuntimeError('Sensor smoke test failed: expected floor and obstacle observations')
            p0=rt.pose()
            moved,stopped=base.move(.12)
            p1=rt.pose()
            forward=(p1[0]-p0[0])*math.cos(p0[2])+(p1[1]-p0[1])*math.sin(p0[2])
            if stopped or not .05 < forward < .19:
                raise RuntimeError(f'Forward smoke test failed: true displacement {forward:.3f} m')
            h0=base.heading()
            base.turn(math.pi/4)
            delta=wrap(base.heading()-h0)
            if abs(delta-math.pi/4) > math.radians(5):
                raise RuntimeError(f'Turn smoke test failed: yaw change {math.degrees(delta):.1f} deg')
            result.update(passed=True,forward_displacement_m=forward,turn_degrees=math.degrees(delta))
        else:
            mission=Mission(cfg,base,camera,log=log)
            if dashboard:
                dashboard.mission = mission
                dashboard.gate()
            if args.person_goal:
                mission.phase = 'searching for person'
                from firebot.isaac.person import acquire_person, plan_person_approach
                cfg.goal_xy = acquire_person(mission,camera,rt,args.person_stop_distance,log)
                cfg.goal_xy = plan_person_approach(mission,args.person_stop_distance,log)
                result['detector'] = 'simulation clothing-color RGB-D proxy; not trained human recognition'
                result['approach_goal'] = cfg.goal_xy
            else:
                mission.scan_and_plan()
            mission.outbound()
            # Return through the exploration route as well as the final approach.
            if args.person_goal:
                mission.driven_out = mission.search_path[:-1] + mission.driven_out
                result['exploration_moves'] = mission.exploration_moves
                result['search_path'] = mission.search_path
            result['true_goal_error_m']=dist(rt.pose()[:2],cfg.goal_xy)
            if person_xy is not None:
                result['true_person_center_distance_m'] = dist(rt.pose()[:2],person_xy)
            if dashboard:
                args.return_obstacle = dashboard.obstacle_option.as_bool
            if args.return_obstacle:
                from firebot.isaac.return_obstacle import ReturnObstacle
                rt.return_obstacle=ReturnObstacle([tuple(p[1:3]) for p in rt.samples],args.seed,
                                                  cfg,rt.boxes,rt.flame,log)
                rt.return_obstacle.previous=rt.pose()[:2]
                log('Random return obstacle armed')
            from firebot.isaac.return_recovery import return_with_exploration
            return_with_exploration(mission,rt,log)
            mission.phase='done'
            result['mission_completed']=True
            result['true_home_error_m']=dist(rt.pose()[:2],(0,0))
            result['estimated_home_error_m']=dist(mission.pose.xy,(0,0))
            result['replans']=mission.replans
            result['passed']=(result['true_goal_error_m']<=cfg.goal_tolerance_m and
                              result['true_home_error_m']<=cfg.goal_tolerance_m)
            if not result['passed']:
                result['error']='Mission finished, but true arrival error exceeded configured tolerance'
            log('Evaluation passed' if result['passed'] else result['error'])
        code=0 if result['passed'] else 2
    except KeyboardInterrupt:
        result['error']='Interrupted by user'
        code=130
    except Exception as exc:
        result['error']=str(exc)
        (args.output/'error.txt').write_text(traceback.format_exc(),encoding='utf-8')
        print('CODEX run failed:',exc,file=sys.stderr)
        code=1
    finally:
        # Startup, perception, control, mission and serialization errors all close Kit.
        try:
            if base is not None:
                try:
                    base.stop()
                except Exception as stop_error:
                    # A closed/stopped Isaac timeline can invalidate the tensor
                    # controller. Preserve the report and still close Kit.
                    result['stop_error']=str(stop_error)
                    result['passed']=False
                    code=1
            if rt is not None:
                if mission is not None:
                    result['return_recovery_moves']=getattr(mission,'return_recovery_moves',0)
                    result['return_recovery_attempts']=getattr(mission,'return_recovery_attempts',0)
                    np.save(args.output/'final_map.npy',mission.grid.state)
                    result['final_estimated_pose']=[mission.pose.x,mission.pose.y,mission.pose.theta]
                if rt.return_obstacle:
                    rt.return_obstacle.finish()
                    result['return_obstacle']=rt.return_obstacle.event
                if mission is not None and args.person_goal:
                    result['exploration_moves'] = getattr(mission,'exploration_moves',0)
                    result['search_path'] = getattr(mission,'search_path',[])
                result['minimum_conservative_clearance_m']={k:v if math.isfinite(v) else None for k,v in rt.min_gaps.items()}
                result['footprint_violation']=rt.violation
                (args.output/'true_trajectory.json').write_text(json.dumps(rt.samples)+'\n')
            if camera is not None and getattr(camera,'last_rgb',None) is not None:
                import cv2
                cv2.imwrite(str(args.output/'camera_rgb.png'),camera.last_rgb[...,::-1])
                np.save(args.output/'camera_depth.npy',camera.last_depth)
            (args.output/'result.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n',encoding='utf-8')
            print(json.dumps(result,indent=2),flush=True)
            if dashboard:
                dashboard.finish(result)
            if args.hold or dashboard:
                # Leave the scene open for inspection after success or failure.
                # This also prevents a navigation exception from making the
                # Isaac window appear to crash or disappear.
                if rt is not None:
                    rt.app_utils.pause()
                while app.is_running() and not (dashboard and dashboard.restart):
                    app.update()
        finally:
            try:
                if rt is not None:
                    rt.shutdown()
            finally:
                if dashboard and dashboard.restart:
                    import subprocess
                    from datetime import datetime
                    # A fresh Isaac process recreates physics, cameras and mission state.
                    from firebot.isaac.dashboard import restart_arguments
                    restart_args = restart_arguments(sys.argv[1:],args.layout,dashboard.selected_layout(),
                        args.output.parent / ('dashboard_'+datetime.now().strftime('%Y%m%d_%H%M%S_%f')))
                    restart_args = [a for a in restart_args if a != '--return-obstacle']
                    if dashboard.obstacle_option.as_bool:
                        restart_args.append('--return-obstacle')
                    subprocess.Popen([sys.executable,'-m','firebot.run_isaac',*restart_args])
                app.close(exit_code=code)
    return code


if __name__=='__main__':
    sys.exit(main())
