#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ $(uname -s) != Linux || $(uname -m) != aarch64 ]]; then
  echo 'Use 64-bit Raspberry Pi OS (aarch64). For a desktop use pip install .[test].' >&2
  exit 1
fi
if [[ $EUID == 0 ]]; then
  echo 'Run as your normal Pi user; the script uses sudo for apt only.' >&2
  exit 1
fi
if [[ ${1:-} != '' && ${1:-} != --camera ]]; then
  echo 'Usage: bash install_pi.sh [--camera]' >&2
  exit 2
fi
sudo apt-get update
sudo apt-get install -y python3-venv python3-dev python3-numpy python3-opencv python3-serial curl
# Reuse Pi OS native NumPy/OpenCV packages to avoid expensive ARM source builds.
python3 -m venv --system-site-packages .venv
.venv/bin/python -m pip install --upgrade pip setuptools
.venv/bin/python -m pip install .
# AprilTag mode uses OpenCV's aruco module. Pi OS's OpenCV build may already
# include it; only install the larger contrib wheel when it does not.
if ! .venv/bin/firebot doctor --markers; then
  .venv/bin/python -m pip install 'opencv-contrib-python-headless>=4.8,<5'
fi
if [[ ${1:-} == --camera ]]; then
  if ! .venv/bin/python -c 'import pyrealsense2; assert hasattr(pyrealsense2, "pipeline")' 2>/dev/null; then
    if ! .venv/bin/python -m pip install --only-binary=:all: 'pyrealsense2>=2.54,<3'; then
      echo 'No matching RealSense wheel. Run bash build_realsense.sh, then rerun this installer.' >&2
      exit 1
    fi
  fi
  curl --fail --location --output .venv/99-realsense-libusb.rules \
    https://raw.githubusercontent.com/realsenseai/librealsense/v2.57.4/config/99-realsense-libusb.rules
  sudo install -m 644 .venv/99-realsense-libusb.rules /etc/udev/rules.d/99-realsense-libusb.rules
  sudo udevadm control --reload-rules
  sudo udevadm trigger
  echo 'Reconnect the RealSense camera to apply USB permissions.'
fi
.venv/bin/firebot doctor --markers
if ! id -nG | tr ' ' '\n' | grep -qx dialout; then
  echo "Serial access: run sudo usermod -aG dialout $(id -un), then log out and back in."
fi
echo 'Installed. Test: .venv/bin/firebot mission --sim'
echo 'Camera/USB check: .venv/bin/firebot doctor --hardware --port /dev/ttyACM0'
echo 'Read README.md for udev rules, firmware selection and calibration before hardware use.'
