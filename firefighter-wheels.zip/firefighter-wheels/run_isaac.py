"""Convenience launcher; invoke using the Isaac Sim desktop Python runtime."""
from firebot.run_isaac import main

if __name__ == '__main__':
    raise SystemExit(main())
