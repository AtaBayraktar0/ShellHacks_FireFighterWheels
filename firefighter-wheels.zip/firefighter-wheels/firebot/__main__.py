from .app import main

if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, ValueError, OSError, ImportError) as exc:
        raise SystemExit(f"Stopped: {exc}") from exc
