"""Single entry point for robot hardware, diagnostics and both simulators."""
import importlib
import sys

COMMANDS = {
    'mission': ('run_mission', 'scan, navigate and return; use --sim without hardware'),
    'calibrate': ('calibrate', 'measure drive speed and turn rate (moves the car)'),
    'drive-test': ('test_drive', 'interactive Uno driver test (moves the car)'),
    'd435-check': ('d435_check', 'check depth, mount geometry and flame detection'),
    'viewer': ('viewer', 'view UDP telemetry on a desktop'),
    'isaac': ('run_isaac', 'run with Isaac Sim Python on a supported desktop'),
    'random-maps': ('random_maps', 'batch Isaac navigation trials'),
    'doctor': ('doctor', 'check dependencies and optionally connected hardware'),
}
PULSE_COMMANDS = ('simulate', 'camera-test', 'serial-test', 'map-scan', 'flame-test', 'run-live')


def main(argv=None):
    args = list(sys.argv[1:] if argv is None else argv)
    if not args or args[0] in ('-h', '--help'):
        print('Usage: firebot COMMAND [options]\n')
        for name, (_, description) in COMMANDS.items():
            print(f'  {name:14} {description}')
        print('\nPulse engine (motor_listener firmware): ' + ', '.join(PULSE_COMMANDS))
        print('Use firebot COMMAND --help for options. See README.md for firmware selection.')
        return 0
    command = args.pop(0)
    if command not in COMMANDS and command not in PULSE_COMMANDS:
        print(f'Unknown command: {command}', file=sys.stderr)
        return 2
    previous = sys.argv
    try:
        module = COMMANDS[command][0] if command in COMMANDS else 'cli'
        sys.argv = ['firebot ' + command] + (args if command in COMMANDS else [command] + args)
        return importlib.import_module('.' + module, __package__).main()
    except (RuntimeError, ValueError, OSError, ImportError) as exc:
        print(f'Stopped: {exc}', file=sys.stderr)
        return 1
    finally:
        sys.argv = previous
