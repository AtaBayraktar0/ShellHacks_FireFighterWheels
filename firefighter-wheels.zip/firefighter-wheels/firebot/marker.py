"""AprilTag recognition and safe conversion of a printed marker into a route goal."""
from dataclasses import dataclass, replace
import math
import time

import numpy as np

from .perception import camera_to_robot
from .rescue_mission import Mission, MissionFailed


_DICTIONARIES = {
    "tag16h5": "DICT_APRILTAG_16h5",
    "tag25h9": "DICT_APRILTAG_25h9",
    "tag36h10": "DICT_APRILTAG_36h10",
    "tag36h11": "DICT_APRILTAG_36h11",
}


@dataclass(frozen=True)
class MarkerDetection:
    """One configured tag, expressed in the robot frame in metres."""
    marker_id: int
    position: tuple
    image_distance_m: float
    depth_distance_m: float | None


def approach_goal(marker_xy, stop_distance_m):
    """Return the point that stops `stop_distance_m` before the marker."""
    x, y = (float(value) for value in marker_xy)
    distance = math.hypot(x, y)
    if distance <= stop_distance_m:
        return (0.0, 0.0)
    scale = (distance - stop_distance_m) / distance
    return (x * scale, y * scale)


class AprilTagDetector:
    """Detect one tag with OpenCV's ArUco/AprilTag module and metric tag size."""

    def __init__(self, cfg, camera_matrix, distortion):
        cfg.validate()
        try:
            import cv2
        except ImportError as exc:
            raise RuntimeError("AprilTag mode requires opencv-contrib-python-headless") from exc
        if not hasattr(cv2, "aruco"):
            raise RuntimeError("AprilTag mode requires OpenCV's aruco module; install opencv-contrib-python-headless")
        dictionary_name = _DICTIONARIES.get(cfg.marker_family)
        if dictionary_name is None or not hasattr(cv2.aruco, dictionary_name):
            raise ValueError(f"Unsupported marker_family: {cfg.marker_family!r}")
        self.cv2, self.cfg = cv2, cfg
        self.dictionary = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, dictionary_name))
        self.parameters = (cv2.aruco.DetectorParameters() if hasattr(cv2.aruco, "ArucoDetector")
                           else cv2.aruco.DetectorParameters_create())
        self.detector = (cv2.aruco.ArucoDetector(self.dictionary, self.parameters)
                         if hasattr(cv2.aruco, "ArucoDetector") else None)
        self.camera_matrix = np.asarray(camera_matrix, dtype=np.float64)
        self.distortion = np.asarray(distortion, dtype=np.float64).reshape(-1, 1)

    def detect(self, bgr, depth, yaw=0.0):
        """Return the configured marker, or None when it is absent or unreliable."""
        if self.detector is not None:
            corners, ids, _ = self.detector.detectMarkers(bgr)
        else:  # Supports OpenCV 4.6 used by some Raspberry Pi OS releases.
            corners, ids, _ = self.cv2.aruco.detectMarkers(bgr, self.dictionary,
                                                            parameters=self.parameters)
        if ids is None:
            return None
        matches = np.flatnonzero(ids.reshape(-1) == self.cfg.marker_id)
        if len(matches) == 0:
            return None
        corners = np.asarray(corners[int(matches[0])], dtype=np.float64).reshape(4, 2)
        half = self.cfg.marker_size_m / 2
        object_points = np.array([[-half, half, 0], [half, half, 0],
                                  [half, -half, 0], [-half, -half, 0]], dtype=np.float64)
        ok, _, translation = self.cv2.solvePnP(object_points, corners, self.camera_matrix,
                                                self.distortion, flags=self.cv2.SOLVEPNP_IPPE_SQUARE)
        if not ok or not np.isfinite(translation).all() or translation[2, 0] <= 0:
            return None
        image_distance = float(np.linalg.norm(translation))
        depth_distance = self._depth_at_marker(depth, corners)
        if self.cfg.marker_require_depth_confirmation:
            if depth_distance is None or abs(depth_distance - translation[2, 0]) > self.cfg.marker_depth_tolerance_m:
                return None
        robot_point = camera_to_robot(translation.reshape(1, 3), self.cfg, yaw)[0]
        if robot_point[0] <= 0:
            return None
        return MarkerDetection(self.cfg.marker_id, tuple(float(value) for value in robot_point),
                               image_distance, depth_distance)

    @staticmethod
    def _depth_at_marker(depth, corners):
        x0, y0 = np.floor(corners.min(axis=0)).astype(int)
        x1, y1 = np.ceil(corners.max(axis=0)).astype(int)
        x0, y0 = max(x0, 0), max(y0, 0)
        x1, y1 = min(x1, depth.shape[1]), min(y1, depth.shape[0])
        values = depth[y0:y1, x0:x1]
        values = values[np.isfinite(values) & (values > 0)]
        return float(np.median(values)) if len(values) else None


class MarkerMission:
    """Find the configured AprilTag, then use its measured position as the route goal."""

    def __init__(self, cfg, base, camera, telemetry=None, log=print):
        cfg.validate()
        self.cfg = replace(cfg, goal_tolerance_m=cfg.marker_center_tolerance_m)
        self.base, self.camera = base, camera
        self.telemetry, self.log = telemetry, log
        # Capture home and gyro reference BEFORE search turns; map bounds stay in
        # the startup frame. Timed turns update the same pose when no IMU exists.
        self.mission = Mission(self.cfg, base, camera, telemetry=telemetry, log=log)

    def run(self):
        detection = self._find_marker()
        goal = approach_goal(detection.position[:2], self.cfg.marker_stop_distance_m)
        if goal == (0.0, 0.0):
            raise MissionFailed("AprilTag is already inside the configured stopping distance")
        self.log(f"Found AprilTag {detection.marker_id}: {detection.image_distance_m:.2f} m away; "
                 f"planning to stop {self.cfg.marker_stop_distance_m:.2f} m before it")
        pose = self.mission.pose
        c, s = math.cos(pose.theta), math.sin(pose.theta)
        self.cfg.goal_xy = (pose.x + c*goal[0] - s*goal[1], pose.y + s*goal[0] + c*goal[1])
        self.mission.goal = self.cfg.goal_xy
        self.mission.run()

    def _find_marker(self):
        deadline = time.monotonic() + self.cfg.marker_search_timeout_s
        try:
            # A fixed camera has zero pan yaw, regardless of requested scan angles.
            yaws = self.cfg.scan_yaws_deg if self.cfg.pan_enabled else (0.0,)
            for yaw_deg in yaws:
                if time.monotonic() >= deadline:
                    break
                yaw = math.radians(yaw_deg)
                self.log(f'Marker search: camera yaw {yaw_deg:.1f} degrees')
                self.base.pan(yaw)
                detection = self.camera.find_marker(yaw)
                if detection and time.monotonic() < deadline:
                    return detection
            self.base.pan(0.0)
            turn = math.radians(self.cfg.marker_search_turn_deg)
            while time.monotonic() < deadline:
                self.log(f'Marker search: turning {self.cfg.marker_search_turn_deg:.1f} degrees')
                self.mission.turn_to_heading(self.mission.pose.theta + turn)
                if time.monotonic() >= deadline:
                    break
                detection = self.camera.find_marker(0.0)
                if detection and time.monotonic() < deadline:
                    return detection
        finally:
            try:
                self.base.stop()
            finally:
                self.base.pan(0.0)
        raise MissionFailed(f"AprilTag {self.cfg.marker_id} was not found within "
                            f"{self.cfg.marker_search_timeout_s:.0f} seconds")
