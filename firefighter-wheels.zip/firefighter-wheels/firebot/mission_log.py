"""Bounded, flushed JSON-line diagnostics for deployed missions."""
from datetime import datetime, timezone
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import platform
import uuid


class MissionLog:
    def __init__(self, directory, max_bytes=5_000_000, backups=3):
        directory = Path(directory)
        directory.mkdir(parents=True, exist_ok=True)
        self.path = directory / 'mission.jsonl'
        self.run_id = uuid.uuid4().hex
        # Open before hardware startup; an unwritable log directory fails safely.
        self.handler = RotatingFileHandler(self.path, maxBytes=max_bytes,
                                           backupCount=backups, encoding='utf-8')
        self.handler.setFormatter(logging.Formatter('%(message)s'))
        self.logger = logging.Logger('firebot.mission.' + self.run_id)
        self.logger.addHandler(self.handler)
        self.event('start', python=platform.python_version(), platform=platform.platform())

    def event(self, event, **data):
        self.logger.info(json.dumps(dict(time=datetime.now(timezone.utc).isoformat(),
                          run_id=self.run_id, event=event, **data), default=str))

    def __call__(self, message):
        print(message)
        self.event('message', message=message)

    def close(self):
        self.handler.close()
        self.logger.removeHandler(self.handler)


class LoggedTelemetry:
    """Keep progress on disk even when no laptop is listening."""
    def __init__(self, log, remote=None):
        self.log, self.remote = log, remote

    def grid(self, grid):
        if self.remote:
            self.remote.grid(grid)

    def state(self, phase, pose, planned, driven_out, driven_back):
        self.log.event('state', phase=phase, pose=[pose.x, pose.y, pose.theta],
                       planned=planned, driven_out=driven_out, driven_back=driven_back)
        if self.remote:
            self.remote.state(phase, pose, planned, driven_out, driven_back)
