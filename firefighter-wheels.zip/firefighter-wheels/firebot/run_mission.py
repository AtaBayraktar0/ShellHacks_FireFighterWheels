"""Scan, navigate to the goal and return, on the Pi or in CPU simulation."""
import argparse
from contextlib import ExitStack
import signal
import traceback
from dataclasses import asdict
from .mission_log import MissionLog, LoggedTelemetry

from .config import Config
from .rescue_mission import Mission, MissionFailed


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config', help='robot.json; required for real hardware')
    p.add_argument('--sim', action='store_true')
    p.add_argument('--enable-motion', action='store_true')
    p.add_argument('--port', help='override USB serial device')
    p.add_argument('--seed', type=int, default=0)
    p.add_argument('--goal', type=float, nargs=2, metavar=('X', 'Y'))
    p.add_argument('--no-imu', action='store_true')
    p.add_argument('--telemetry', metavar='HOST[:PORT]')
    p.add_argument('--plot', metavar='PNG')
    p.add_argument('--log-dir', default='runs/logs', help='persistent rotating logs (default: runs/logs)')
    args = p.parse_args()
    log = MissionLog(args.log_dir)
    print(f'Troubleshooting log: {log.path.resolve()}')
    try:
        code = _execute(args, p, log)
        log.event('end', exit_code=code)
        return code
    except BaseException as exc:
        log.event('exception', error=str(exc), traceback=traceback.format_exc())
        code = exc.code if isinstance(exc, SystemExit) else 130 if isinstance(exc, KeyboardInterrupt) else 1
        log.event('end', exit_code=code)
        raise
    finally:
        log.close()


def _execute(args, p, log):
    if not args.sim and (not args.enable_motion or not args.config):
        p.error('hardware requires --enable-motion and --config robot.json (uno_driver firmware)')
    cfg = Config.load(args.config)
    if args.sim and cfg.goal_mode == 'apriltag':
        p.error('AprilTag goal mode needs a real D435 camera; use goal_mode="coordinate" for --sim')
    if args.goal and cfg.goal_mode == 'apriltag':
        p.error('--goal cannot override an AprilTag goal')
    if not args.sim and cfg.calibrated is not True:
        p.error('measure motion, camera mount and arena; then set calibrated=true in robot.json')
    if args.goal:
        cfg.goal_xy = tuple(args.goal)
    if args.port:
        cfg.port = args.port
    if args.no_imu:
        cfg.use_imu = False
    log.event('configuration', config=asdict(cfg), simulation=args.sim)
    if cfg.goal_mode == 'apriltag':
        # Fail before opening serial if this OpenCV build cannot create the detector.
        import numpy as np
        from .marker import AprilTagDetector
        AprilTagDetector(cfg, np.eye(3), np.zeros(5))
    tel = None
    if args.telemetry:
        from .telemetry import Telemetry
        host, _, port = args.telemetry.partition(':')
        tel = Telemetry(host, int(port or 5005))
    tel = LoggedTelemetry(log, tel)
    world = mission = None
    # SIGTERM (including service shutdown) uses the same cleanup as Ctrl-C.
    def terminate(signum, frame):
        raise KeyboardInterrupt
    previous = signal.signal(signal.SIGTERM, terminate)
    try:
        with ExitStack() as cleanup:
            if args.sim:
                from .sim import SimBase, SimCamera, SimWorld
                world = SimWorld.demo(cfg, seed=args.seed)
                base, camera = SimBase(world), SimCamera(world)
            else:
                from .base import UnoBase
                from .perception import D435Camera
                from .uno_link import UnoLink
                uno = UnoLink(cfg.port, on_event=lambda e: log(f'  [uno] {e}'))
                # Register before open so partial startup is cleaned up as well.
                cleanup.callback(uno.close)
                uno.open()
                base = UnoBase(uno, cfg)
                cleanup.callback(base.stop)
                camera = D435Camera(cfg)
                cleanup.callback(camera.close)
            if cfg.goal_mode == 'apriltag':
                from .marker import MarkerMission
                mission = MarkerMission(cfg, base, camera, telemetry=tel, log=log)
            else:
                mission = Mission(cfg, base, camera, telemetry=tel, log=log)
            mission.run()
        if args.plot:
            from .viz import plot_mission
            plot_mission(mission.mission if cfg.goal_mode == 'apriltag' else mission, args.plot, world)
            log(f'Saved {args.plot}')
        if world:
            log(f'Sim: {world.collisions} collisions, true end position '
                  f'({world.pose.x:.2f}, {world.pose.y:.2f})')
        return 0
    except MissionFailed as exc:
        log.event('exception', error=str(exc), traceback=traceback.format_exc())
        log(f'Mission failed: {exc}')
        return 1
    except KeyboardInterrupt:
        log('Stopped by user or shutdown signal')
        return 130
    finally:
        signal.signal(signal.SIGTERM, previous)


if __name__ == '__main__':
    raise SystemExit(main())
