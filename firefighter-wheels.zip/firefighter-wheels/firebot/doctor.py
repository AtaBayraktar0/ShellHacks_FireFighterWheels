"""Deployment checks; hardware enumeration never sends movement commands."""
import argparse
import importlib
import os
import platform


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--hardware', action='store_true', help='also require RealSense SDK and a connected camera')
    parser.add_argument('--port', help='check read/write access to this serial device without opening it')
    parser.add_argument('--markers', action='store_true', help='exercise AprilTag detection without hardware')
    args = parser.parse_args()
    print(f'{platform.system()} {platform.machine()} / Python {platform.python_version()}')
    ok = True
    for name in ['numpy', 'cv2', 'serial'] + (['pyrealsense2'] if args.hardware else []):
        try:
            mod = importlib.import_module(name)
            print(f'OK {name}: {getattr(mod, "__version__", "installed")}')
            if name == 'pyrealsense2':
                devices = list(mod.context().query_devices())
                if not devices:
                    raise RuntimeError('no RealSense camera detected; check USB 3, power and udev rules')
                print(f'OK RealSense devices: {len(devices)}')
        except (ImportError, OSError, RuntimeError) as exc:
            print(f'FAIL {name}: {exc}')
            ok = False
    if args.markers:
        try:
            import numpy as np
            from .config import Config
            from .marker import AprilTagDetector
            detector = AprilTagDetector(Config(), np.eye(3), np.zeros(5))
            detector.detect(np.full((64, 64, 3), 255, np.uint8), np.ones((64, 64)))
            print('OK AprilTag detection')
        except Exception as exc:
            print(f'FAIL AprilTag detection: {exc}')
            ok = False
    if args.port:
        accessible = os.path.exists(args.port) and os.access(args.port, os.R_OK | os.W_OK)
        print(f'{"OK" if accessible else "FAIL"} serial access: {args.port}')
        ok = ok and accessible
    return 0 if ok else 1
