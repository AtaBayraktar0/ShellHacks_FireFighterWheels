"""Created by OpenAI Codex: mission adapter controlling physical wheel joints.

Distance remains time-based, as on the real robot. Heading uses an ideal
simulated gyro (physics yaw). Ground-truth XY is never fed to the mission.
"""
import math
from firebot.geometry import wrap
from firebot.rescue_mission import MissionFailed


class IsaacBase:
    def __init__(self, runtime, cfg):
        self.rt, self.cfg = runtime, cfg
        self.camera = None

    def heading(self):
        return self.rt.pose()[2]

    def pan(self, yaw):
        if self.camera is not None:
            self.camera.pan(yaw)
        self.rt.wait(self.cfg.pan_settle_s)

    def stop(self):
        self.rt.command(0.,0.)

    def turn(self, angle):
        initial = previous = self.heading()
        turned = 0.
        integral = 0.
        previous_time = self.rt.time()
        deadline = self.rt.time() + 8. + abs(angle)/.15
        try:
            while abs(angle-turned) > math.radians(1.):
                if self.rt.time() > deadline:
                    raise MissionFailed('Isaac turn timed out: check wheel joints/friction/gyro')
                error = angle-turned
                now = self.rt.time()
                dt = max(0., now-previous_time)
                previous_time = now
                integral = max(-.8, min(.8, integral+error*dt))
                demand = 2.*error + 1.5*integral
                omega = max(-1.5, min(1.5, demand))
                if omega*error <= 0:
                    integral = 0.
                    omega = math.copysign(.4,error)
                elif abs(omega) < .4:
                    omega = math.copysign(.4,error)
                self.rt.command(0.,omega)
                self.rt.step()
                current = self.heading()
                turned += wrap(current-previous)
                previous = current
        finally:
            self.stop()
        self.rt.wait(self.cfg.settle_s)
        return turned + wrap(self.heading()-previous)

    def move(self, distance):
        hold = self.heading()
        start = self.rt.time()
        stopped = False
        elapsed = 0.
        try:
            while elapsed < distance/self.cfg.speed_mps:
                if self.rt.sonar_distance() < self.cfg.sonar_stop_m:
                    stopped = True
                    break
                error = wrap(hold-self.heading())
                self.rt.command(self.cfg.speed_mps,max(-.6,min(.6,3.*error)))
                self.rt.step()
                elapsed = self.rt.time()-start
        finally:
            self.stop()
        moved = min(distance,elapsed*self.cfg.speed_mps)
        self.rt.wait(self.cfg.settle_s)
        return moved,stopped
