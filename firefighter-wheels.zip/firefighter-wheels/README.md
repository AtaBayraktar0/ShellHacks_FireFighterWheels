# Firefighter Wheels — unified Raspberry Pi project

The former `FIRE_ROBOT_CODEX/pi/rescue` and `firebot` code now live in one
installable `firebot` package, with one `firebot` command. There is no nested
copy of the project and no `sys.path` workaround. The two existing navigation
engines are retained because their map models and motor protocols differ.

## Folder layout

```text
firefighter-wheels/
  firebot/                 all Python code; only Isaac has its own subpackage
    isaac/                 optional desktop simulation and bundled Kit resource
  firmware/
    uno_driver/            full mission, gyro, pan servo and ultrasonic support
    motor_listener/        alternative bounded-pulse motor protocol
  tests/                   combined regression tests
  robot.json               full mission configuration, initially uncalibrated
  config.json              editable pulse-engine configuration
  install_pi.sh            Raspberry Pi installer
  build_realsense.sh       camera SDK source fallback
  pyproject.toml           one dependency and packaging definition
```

Arduino sketch folders must match their `.ino` filenames. Tests and the optional
Isaac code are separate to keep hardware deployment understandable. `.venv` and
`runs` are generated only when installing/running. Historical authorship and
prior validation notes are retained in `HISTORY.md`; they describe the old copy.

## Raspberry Pi setup

Target: Raspberry Pi 4 or 5, **64-bit Raspberry Pi OS**, Python 3.10 or newer,
an Intel RealSense D435 on USB 3, and an Arduino Uno with the appropriate Elegoo
motor shield. The Pi sends USB serial commands; it does not drive motor GPIO.
Use adequate Pi/camera power and the car's motor power supply.

Copy this entire folder onto the Pi, open a terminal inside it, and run:

```bash
bash install_pi.sh --camera
source .venv/bin/activate
firebot doctor
firebot mission --sim
```

For CPU simulation without a camera SDK, omit `--camera`. The installer creates
a virtual environment using the Pi OS NumPy, OpenCV and serial packages, then
installs this project. Re-run it after updating the code. Do not run it as root.
Python virtual environments follow the [Raspberry Pi OS guidance](https://www.raspberrypi.com/documentation/computers/os.html#python-on-raspberry-pi).

If the camera wheel is unavailable for your Python/ARM combination:

```bash
bash build_realsense.sh
bash install_pi.sh --camera
```

The fallback builds SDK `v2.57.4` with its USB userspace backend and Python
bindings. It defaults to two compilation jobs; `BUILD_JOBS=1` reduces memory
pressure. `REALSENSE_REF` selects another tag on the first clone. The SDK build
is cached in `.realsense-build`. See the [official Python wrapper build instructions](https://github.com/realsenseai/librealsense/blob/master/wrappers/python/readme.md).
Both camera setup paths install USB udev rules; unplug/replug the camera afterward.

If you are not in the serial-access group:

```bash
sudo usermod -aG dialout "$USER"
```

Log out and back in. Find the Uno with `ls /dev/serial/by-id/` and use its stable
path as `port` in `robot.json`, or pass `--port`. Then check:

```bash
firebot doctor --hardware --port /dev/ttyACM0
```

`doctor` checks imports, camera enumeration and serial file permissions. It does
not prove firmware compatibility or send motor commands.

## Firmware and command selection

Flash **one** matching sketch to the Uno using Arduino IDE (board: Arduino Uno).
Select its USB port, open the `.ino` below, and Upload. `uno_driver` needs the
Arduino Servo library and Wire; install Servo using Library Manager if missing.
Close Serial Monitor before using the Pi.

| Commands | Uno sketch | Configuration |
| --- | --- | --- |
| `mission`, `calibrate`, `drive-test` | `firmware/uno_driver/uno_driver.ino` | `robot.json` |
| `serial-test`, `run-live` | `firmware/motor_listener/motor_listener.ino` | `config.json` |
| `simulate`, `mission --sim`, `isaac` | none | engine-specific |

Both protocols use 115200 baud but are incompatible. The full driver uses
`M left right`, `S`, `P`, `H`, `V angle`, and `D`, with a 500 ms watchdog.
The pulse driver uses `FWD/BACK/LEFT/RIGHT pwm milliseconds` and `STOP`, with
firmware-enforced pulses of at most 200 ms. Do not mix a command family with
the other sketch. Replacing either protocol would change its stop guarantees,
so both original firmware choices are retained.

Existing shield assignments are right PWM 5, left PWM 6, right direction 7,
left direction 8, standby 3. The full driver additionally uses sonar trigger
13/echo 12, pan servo 11, and MPU6050 I2C A4/A5. Verify these against your shield
revision before connecting power.

## Run the full mission on the Pi

After flashing `uno_driver`, from this project folder:

```bash
firebot d435-check --config robot.json --floor
firebot d435-check --config robot.json --flame
firebot drive-test --port /dev/ttyACM0
firebot calibrate --config robot.json
```

The last two commands move the car after an interactive prompt; first test with
wheels lifted. Calibration writes measured speed and turn rate to `robot.json`.
Set the serial port there before calibration. Measure camera height/pitch/offset,
robot footprint, arena bounds, goal and sensor orientation too. Use `use_imu=false`
or `--no-imu` only for timed turning without the MPU6050. Set `pan_enabled=false`
when no camera pan servo is fitted. Defaults describe the simulation arena and
are not measurements of your car. Once reviewed, set `"calibrated": true`.

```bash
firebot mission --config robot.json --enable-motion
```

Ctrl-C or SIGTERM stops and releases hardware. Startup failures also close the
serial connection. A missing explicit config file is an error. Live missions
require both the calibrated flag and `--enable-motion`.

## Use an AprilTag as the goal

The normal setting, `"goal_mode": "coordinate"`, uses `goal_xy`. To use a
printed AprilTag as the destination, install the updated project dependencies
and change the marker section in `robot.json`:

```json
"goal_mode": "apriltag",
"marker_family": "tag36h11",
"marker_id": 0,
"marker_size_m": 0.10,
"marker_stop_distance_m": 0.25,
"marker_center_tolerance_m": 0.05
```

Print a `tag36h11` tag with ID 0 whose **outside black-square width** measures
exactly 10 cm, mount it flat and upright at the destination, then run the same
hardware command:

```bash
firebot mission --config robot.json --enable-motion
```

With a pan mount, the D435 first scans its pan positions; a fixed camera looks
straight ahead. The robot then searches by turning in 30-degree steps. The
30-second search budget includes the initial scan; an in-progress camera read
or turn must finish before the deadline can be checked. It estimates tag distance from its known printed width and, by
default, rejects a tag unless aligned RealSense depth agrees within 20 cm. After
finding the tag, it plans to a point 25 cm before it, with a 5 cm approach-point
tolerance, and returns home. `goal_xy`
remains a simulation/coordinate-mode fallback. AprilTag mode is for a real D435
and cannot run with `--sim` or the Isaac runner. Search turns preserve the
startup coordinate frame and arena bounds. The detected tag becomes a fixed
waypoint; the robot does not continuously track a moving tag or make final
vision-based corrections. Check detection support with `firebot doctor --markers`.

The full mission estimates translation from measured speed and elapsed time;
there are no wheel encoders or SLAM here. Drift depends on battery and surface.
The color detector identifies an orange/red flame prop, not a certified fire
detector. Existing unknown-cell and clearance-fallback policies are preserved
and exposed in `robot.json`; review them for your arena.

For a laptop telemetry display, install the viewer extra on the laptop and run:

```bash
python -m pip install '.[viewer]'
firebot viewer
```

On the Pi add `--telemetry LAPTOP_IP:5005` to the mission command. Allow UDP 5005
on the laptop. Plotting is optional (`pip install '.[viewer]'`, then `--plot run.png`).

## Troubleshooting logs on the Raspberry Pi

Every `firebot mission` run automatically saves `runs/logs/mission.jsonl`, relative
to the folder where you start it. The terminal prints the full log path. To keep
logs in a fixed location, add `--log-dir /path/to/writable/logs` to the command.
Use one mission process at a time.

Each line is a JSON record with a UTC timestamp and a unique run ID. Records
include the effective configuration, estimated pose and route progress, marker
search steps, Arduino events, completion status, and Python error tracebacks.
This records estimates and messages, not raw camera video or every sensor sample.
Logs flush after each record. They rotate at about 5 MB and retain three backups
(`mission.jsonl.1` through `.3`), about 20 MB total. Oldest records are eventually
replaced, so copy the files after a problem. An unwritable directory prevents
startup; later disk errors print to stderr. Abrupt power loss may lose recent
writes and will not produce a normal end record.

On the Pi, watch the log while troubleshooting:

```bash
tail -f runs/logs/mission.jsonl
```

Keep the log files and the robot configuration when reporting a failure. The
default `runs/` directory is excluded from Git. These automatic logs cover
`firebot mission`; the pulse engine and Isaac commands retain their existing
`--output` results. Diagnostic commands such as `doctor` print to the terminal.

## Original pulse engine commands

```bash
firebot simulate --config config.json --output runs/demo
firebot simulate --config config.json --block-return --output runs/blocked
firebot camera-test --config config.json
firebot serial-test --config config.json --port /dev/ttyACM0
```

`serial-test` sends STOP only unless `--enable-motion` is supplied. This engine's
live mode requires an external localization process writing fresh pose JSON
(`x`, `y` in metres, `yaw` in radians, `timestamp` as Unix seconds), atomically,
in the map's world frame. No localization provider is included. The D435 supplies
depth, not world pose. Set its separate calibrated config only after measuring it:

```bash
firebot run-live --config config.json --pose-file /path/to/pose.json --enable-motion
```

If `--config` is omitted for pulse commands, a packaged default is used, so they
also work outside the source folder. Pass `--config config.json` to use edits to
the root file. Full mission and pulse configs must not be interchanged.

## Desktop simulation and development

CPU simulation needs no camera or Arduino. On a desktop:

```bash
python -m venv .venv
# Activate .venv using your platform's shell.
python -m pip install '.[test]'
python -m pytest -q
python -m firebot mission --sim
python -m firebot simulate
```

The POSIX pseudo-terminal serial tests run on Linux/macOS and skip on Windows.
The existing Isaac integration targets Isaac Sim 6.1 and requires its desktop
runtime; it is not part of Raspberry Pi installation. From the project folder:

```bash
/path/to/isaac-sim/python.sh run_isaac.py --layout room --sensor raycast
/path/to/isaac-sim/python.sh test_random_maps.py --runs 10
```

On Windows use the Isaac `python.bat` instead. Alternatively, install this project
into that runtime and run `python -m firebot isaac`. RGB-D and raycast adapters,
room/random layouts, stage export and batch reports are retained.

## Validation limits

See `VALIDATION.md` for checks performed on this merged version. Raspberry Pi
installation, physical driving and firmware upload still need testing on their
target hardware. The validation notes distinguish CPU tests from actual Isaac runs.
