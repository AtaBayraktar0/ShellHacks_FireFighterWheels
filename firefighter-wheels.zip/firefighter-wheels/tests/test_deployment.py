"""Regression coverage for the merge and hardware startup cleanup."""
import sys
from unittest.mock import Mock
import pytest
from firebot.app import main
from firebot.config import Config


def test_missing_explicit_config_does_not_use_defaults(tmp_path):
    with pytest.raises(FileNotFoundError):
        Config.load(tmp_path / 'missing.json')


def test_hardware_requires_explicit_motion_flag():
    with pytest.raises(SystemExit) as exc:
        main(['mission'])
    assert exc.value.code == 2


def test_uncalibrated_config_rejected_before_serial(tmp_path):
    config = tmp_path / 'robot.json'
    Config().save(config)
    with pytest.raises(SystemExit) as exc:
        main(['mission', '--enable-motion', '--config', str(config)])
    assert exc.value.code == 2


def test_serial_closed_when_camera_startup_fails(tmp_path, monkeypatch):
    from firebot import uno_link, base, perception
    config = tmp_path / 'robot.json'
    Config(calibrated=True).save(config)
    uno = Mock()
    robot = Mock()
    monkeypatch.setattr(uno_link, 'UnoLink', Mock(return_value=uno))
    monkeypatch.setattr(base, 'UnoBase', Mock(return_value=robot))
    monkeypatch.setattr(perception, 'D435Camera', Mock(side_effect=RuntimeError('camera unplugged')))
    assert main(['mission', '--enable-motion', '--config', str(config)]) == 1
    robot.stop.assert_called_once()
    uno.close.assert_called_once()


def test_command_restores_argv():
    original = sys.argv
    with pytest.raises(SystemExit) as exc:
        main(['doctor', '--help'])
    assert exc.value.code == 0
    assert main(['does-not-exist']) == 2
    assert sys.argv is original


def test_marker_plot_receives_navigation_mission(tmp_path, monkeypatch):
    from types import SimpleNamespace
    from firebot import uno_link, base, perception, marker
    config = tmp_path / 'robot.json'
    Config(calibrated=True, goal_mode='apriltag').save(config)
    monkeypatch.setattr(uno_link, 'UnoLink', Mock())
    monkeypatch.setattr(base, 'UnoBase', Mock())
    monkeypatch.setattr(perception, 'D435Camera', Mock())
    monkeypatch.setattr(marker, 'AprilTagDetector', Mock())
    wrapper = Mock()
    monkeypatch.setattr(marker, 'MarkerMission', Mock(return_value=wrapper))
    plot = Mock()
    monkeypatch.setitem(sys.modules, 'firebot.viz', SimpleNamespace(plot_mission=plot))
    assert main(['mission', '--enable-motion', '--config', str(config),
                 '--plot', str(tmp_path / 'route.png')]) == 0
    assert plot.call_args.args[0] is wrapper.mission
