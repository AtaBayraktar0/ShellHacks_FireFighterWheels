import math

import numpy as np
import pytest

from firebot.config import Config
from firebot.marker import approach_goal


@pytest.mark.parametrize('field,value', [
    ('marker_size_m', float('nan')), ('marker_stop_distance_m', float('inf')),
    ('marker_search_timeout_s', True), ('marker_id', True),
    ('marker_id', 587), ('marker_family', 'unknown'),
    ('scan_yaws_deg', [float('nan')]), ('marker_require_depth_confirmation', 'false'),
])
def test_invalid_marker_configuration(field, value):
    with pytest.raises(ValueError):
        Config(**{field: value}).validate()


@pytest.mark.parametrize('imu', [True, False])
def test_fixed_camera_search_preserves_startup_frame(monkeypatch, imu):
    from firebot.marker import MarkerMission, MarkerDetection
    class Base:
        yaw = 0.4
        stopped = False
        def heading(self):
            return self.yaw if imu else None
        def pan(self, yaw):
            assert yaw == 0.0
        def turn(self, angle):
            self.yaw += angle
            return angle
        def stop(self):
            self.stopped = True
    class Camera:
        calls = 0
        def find_marker(self, yaw):
            assert yaw == 0.0
            self.calls += 1
            if self.calls == 2:
                return MarkerDetection(0, (2., 0., 0.), 2., 2.)
    cfg = Config(goal_mode='apriltag', pan_enabled=False, marker_search_turn_deg=90)
    original_goal = cfg.goal_xy
    base = Base()
    wrapper = MarkerMission(cfg, base, Camera(), log=lambda _: None)
    monkeypatch.setattr(wrapper.mission, 'run', lambda: None)
    wrapper.run()
    assert wrapper.mission.goal == pytest.approx((0., 1.75))
    assert wrapper.mission.start == (0., 0.)
    assert cfg.goal_xy == original_goal
    assert base.stopped


def test_search_camera_failure_stops_and_recenters():
    from unittest.mock import Mock
    from firebot.marker import MarkerMission
    base = Mock()
    base.heading.return_value = None
    camera = Mock()
    camera.find_marker.side_effect = RuntimeError('camera disconnected')
    wrapper = MarkerMission(Config(), base, camera)
    with pytest.raises(RuntimeError, match='disconnected'):
        wrapper.run()
    base.stop.assert_called_once()
    base.pan.assert_called_with(0.0)


def test_initial_scan_counts_against_search_timeout(monkeypatch):
    from unittest.mock import Mock
    from firebot import marker
    base = Mock()
    base.heading.return_value = None
    camera = Mock()
    camera.find_marker.return_value = marker.MarkerDetection(0, (2., 0., 0.), 2., 2.)
    times = iter([0., 0., 31., 31., 31.])
    monkeypatch.setattr(marker.time, 'monotonic', lambda: next(times))
    wrapper = marker.MarkerMission(Config(), base, camera)
    with pytest.raises(marker.MissionFailed, match='not found'):
        wrapper.run()
    base.turn.assert_not_called()
    base.stop.assert_called_once()


def test_marker_goal_stops_before_the_tag():
    assert approach_goal((2.0, 0.0), 0.25) == pytest.approx((1.75, 0.0))
    assert approach_goal((2.0, 2.0), math.sqrt(2)) == pytest.approx((1.0, 1.0))


def test_marker_goal_is_zero_when_tag_is_already_too_close():
    assert approach_goal((0.2, 0.0), 0.25) == (0.0, 0.0)


def test_marker_config_is_accepted_and_invalid_stop_distance_rejected(tmp_path):
    cfg = Config(goal_mode="apriltag", marker_id=7, marker_size_m=0.12,
                 marker_stop_distance_m=0.30)
    path = tmp_path / "marker.json"
    cfg.save(path)
    loaded = Config.load(path)
    assert loaded.goal_mode == "apriltag"
    assert loaded.marker_id == 7
    with pytest.raises(ValueError, match="robot radius"):
        Config(marker_stop_distance_m=0.10).validate()


def test_apriltag_detector_uses_printed_size_and_depth():
    cv2 = pytest.importorskip("cv2")
    if not hasattr(cv2, "aruco"):
        pytest.skip("OpenCV was built without AprilTag support")
    from firebot.marker import AprilTagDetector
    cfg = Config(goal_mode="apriltag", marker_size_m=0.10, cam_forward_m=0.0,
                 cam_height_m=0.0, cam_pitch_deg=0.0, marker_depth_tolerance_m=0.10)
    dictionary = cv2.aruco.getPredefinedDictionary(cv2.aruco.DICT_APRILTAG_36h11)
    generate = getattr(cv2.aruco, "generateImageMarker", None) or cv2.aruco.drawMarker
    tag = generate(dictionary, cfg.marker_id, 120)
    image = np.full((480, 640), 255, np.uint8)
    image[180:300, 260:380] = tag
    bgr = cv2.cvtColor(image, cv2.COLOR_GRAY2BGR)
    depth = np.full((480, 640), 0.50, dtype=float)
    camera = np.array([[600., 0., 320.], [0., 600., 240.], [0., 0., 1.]])
    detection = AprilTagDetector(cfg, camera, np.zeros(5)).detect(bgr, depth)
    assert detection is not None
    assert detection.marker_id == 0
    assert detection.image_distance_m == pytest.approx(0.50, abs=0.03)
    assert detection.depth_distance_m == pytest.approx(0.50)
    assert detection.position == pytest.approx((0.50, 0.0, 0.0), abs=0.03)
