import json
from unittest.mock import Mock

from firebot.app import main
from firebot.config import Config
from firebot.mission_log import MissionLog


def records(path):
    return [json.loads(line) for line in path.read_text().splitlines()]


def test_simulation_writes_configuration_progress_and_completion(tmp_path):
    assert main(['mission', '--sim', '--log-dir', str(tmp_path)]) == 0
    entries = records(tmp_path / 'mission.jsonl')
    assert {'start', 'configuration', 'state', 'message', 'end'} <= {e['event'] for e in entries}
    assert entries[-1]['exit_code'] == 0
    assert len({e['run_id'] for e in entries}) == 1
    assert all(e['time'].endswith('+00:00') for e in entries)


def test_startup_error_logged_and_hardware_closed(tmp_path, monkeypatch):
    from firebot import uno_link, base, perception
    config = tmp_path / 'robot.json'
    Config(calibrated=True).save(config)
    uno, robot = Mock(), Mock()
    monkeypatch.setattr(uno_link, 'UnoLink', Mock(return_value=uno))
    monkeypatch.setattr(base, 'UnoBase', Mock(return_value=robot))
    monkeypatch.setattr(perception, 'D435Camera', Mock(side_effect=RuntimeError('camera unplugged')))
    assert main(['mission', '--enable-motion', '--config', str(config), '--log-dir', str(tmp_path)]) == 1
    error = next(e for e in records(tmp_path / 'mission.jsonl') if e['event'] == 'exception')
    assert 'camera unplugged' in error['traceback']
    robot.stop.assert_called_once()
    uno.close.assert_called_once()


def test_log_rotation_is_bounded_and_new_runs_are_identifiable(tmp_path):
    first = MissionLog(tmp_path, max_bytes=700, backups=2)
    for i in range(30):
        first.event('sample', index=i, detail='x' * 100)
    first.close()
    second = MissionLog(tmp_path, max_bytes=700, backups=2)
    second.close()
    files = list(tmp_path.glob('mission.jsonl*'))
    assert len(files) == 3
    assert all(p.stat().st_size < 700 for p in files)
    assert records(tmp_path / 'mission.jsonl')[-1]['run_id'] == second.run_id
    assert second.run_id != first.run_id
