"""Convenience launcher for randomized Isaac trials."""
from firebot.random_maps import main

if __name__ == '__main__':
    raise SystemExit(main())
