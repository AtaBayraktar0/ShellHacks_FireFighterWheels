# Validation of the unified project

## Persistent mission logs — version 0.2.2, 2026-09-27

- Added automatic rotating JSON-line logs for the main Raspberry Pi mission,
  including configuration, estimated pose/routes, marker search, Arduino events,
  exit status, and error tracebacks. Default destination is `runs/logs`;
  `--log-dir` selects a fixed writable deployment directory.
- Regression suite: **76 passed, 1 skipped** with OpenCV 4.8.1. New tests verify
  successful mission records, camera failure logging with hardware cleanup,
  rotation limits, and distinct identifiers across runs.
- This update does not change motion control. No additional physical Pi or
  Isaac trials were performed for the logging update; prior results are below.
- Logging covers `firebot mission`. Other commands retain their existing output
  behavior. Camera video is not recorded, and abrupt power loss can lose recent
  filesystem writes. One mission process should run at a time.

## Integrity fixes — version 0.2.1, 2026-09-27

Fixed fixed-camera marker yaw, retained the startup coordinate frame through
marker search turns (with and without IMU), validated finite marker settings and
family/ID ranges, restored OpenCV 4.6 compatibility, and corrected marker plotting.
Search timeout includes the first scan; failure cleanup stops and recenters the camera.
The installer now exercises AprilTag detection through `firebot doctor --markers`.

Isaac raycasts now classify random-layout flames, clearance checks use the actual
rectangular flame footprint, and the process exit code reflects the result.
Isaac explicitly rejects unsupported AprilTag missions.

- Final suite: **73 passed, 1 skipped**, Python 3.12.14, NumPy 1.26.4,
  OpenCV contrib 4.8.1, pytest 9.1.1. The skipped module requires POSIX serial terminals.
- OpenCV 4.6: the earlier 71-test suite passed and marker diagnostics passed.
- Built version 0.2.1 wheel, installed outside the source tree, and completed
  a CPU round trip with zero collisions.
- Pi installer passed `bash -n`.
- Actual Isaac 6.1 runtime, random seed 0, raycast full mission: passed, exit 0;
  goal error 0.01024 m, home error 0.02143 m, no footprint violation.
- Actual Isaac RGB-D demo smoke test: passed, exit 0; forward motion 0.11939 m,
  turn 44.28 degrees, no footprint violation.
- Deliberate Isaac timeout: failed as expected, exit 1.
- RGB-D random seed 0 smoke test stopped near an obstacle and correctly failed
  with exit 1; the demo layout was used for the unobstructed movement check.

Nested project copies and old build artifacts were preserved under workspace
`work/integrity-fix-backup`, outside this single project root. Existing `runs`
were retained locally; the distributable ZIP excludes runs, caches and build artifacts.

This is targeted regression validation, not a rerun of the previous 15-trial
study. Historical reports remain unchanged. Real Raspberry Pi installation,
physical marker navigation, motors, camera and firmware remain unverified.
Marker acquisition produces a fixed waypoint, not continuous visual tracking.

## Historical validation before these fixes

Validated on Windows AMD64, Python 3.12.14, on 2026-09-27.

- Combined pytest suite: **54 passed, 1 skipped**. The skipped module contains
  POSIX pseudo-terminal serial tests and requires Linux/macOS.
- Both original CPU test suites and Isaac adapter math tests are included.
- Added regressions for missing configuration, motion authorization,
  calibration gating, serial/motor cleanup when camera startup fails, and CLI
  argument restoration.
- Built the installable Python wheel and installed it into an isolated target
  directory. Ran commands from outside the source tree.
- Installed-package `doctor` passed for NumPy, OpenCV and pyserial.
- Installed-package `mission --sim` completed its round trip with zero collisions.
- Installed-package pulse `simulate` completed; `--block-return` detected the
  blocked return route as expected.
- Installed-package Isaac help loaded without importing the Isaac runtime.
- Verified packaged pulse config and Isaac `.kit` resource are present.
- Both Pi shell scripts passed `bash -n`; both use LF line endings.
- Verified the pinned RealSense SDK tag provides the referenced USB udev rules.

Test dependencies: NumPy 2.5.3, OpenCV 4.14.0, pyserial 3.5, pytest 9.1.1.
The Pi installer instead uses Pi OS native NumPy/OpenCV/serial packages.

Not executed here: apt installation on Raspberry Pi OS, ARM RealSense source
compilation, USB camera capture, physical motors/gyro/sonar, Arduino compilation
or upload, and full Isaac Sim physics/rendering. Those need their target
hardware/runtimes. Run `python -m pytest -q` on the Pi for the POSIX tests and
follow README.md for physical commissioning.
