#!/usr/bin/env bash
# Source fallback when no wheel matches the Pi OS Python/ARM combination.
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
[[ -x .venv/bin/python ]] || { echo 'Run bash install_pi.sh first.' >&2; exit 1; }
[[ $EUID != 0 ]] || { echo 'Run as a normal user.' >&2; exit 1; }
sudo apt-get install -y git cmake build-essential pkg-config libusb-1.0-0-dev libssl-dev python3-dev
sdk="$PWD/.realsense-build/librealsense"
if [[ ! -d "$sdk" ]]; then
  git clone --depth 1 --branch "${REALSENSE_REF:-v2.57.4}" https://github.com/realsenseai/librealsense.git "$sdk"
fi
python_bin="$PWD/.venv/bin/python"
site_dir=$("$python_bin" -c 'import sysconfig; print(sysconfig.get_path("platlib"))')
cmake -S "$sdk" -B "$sdk/build" \
  -DCMAKE_BUILD_TYPE=Release -DFORCE_RSUSB_BACKEND=ON \
  -DBUILD_EXAMPLES=OFF -DBUILD_GRAPHICAL_EXAMPLES=OFF \
  -DBUILD_PYTHON_BINDINGS=ON -DBUILD_SHARED_LIBS=OFF \
  -DPYTHON_EXECUTABLE="$python_bin" -DPython_EXECUTABLE="$python_bin" \
  -DCMAKE_INSTALL_PREFIX="$PWD/.realsense-build/install"
cmake --build "$sdk/build" --parallel "${BUILD_JOBS:-2}"
found=0
while IFS= read -r -d '' module; do
  cp -- "$module" "$site_dir/"
  found=1
done < <(find "$sdk/build" -type f -name 'pyrealsense2*.so' -print0)
[[ $found == 1 ]] || { echo 'Build produced no Python module.' >&2; exit 1; }
sudo install -m 644 "$sdk/config/99-realsense-libusb.rules" /etc/udev/rules.d/99-realsense-libusb.rules
sudo udevadm control --reload-rules
sudo udevadm trigger
"$python_bin" -c 'import pyrealsense2 as rs; print("RealSense SDK ready:", rs.pipeline)'
echo 'Reconnect the camera, then run .venv/bin/firebot doctor --hardware'
